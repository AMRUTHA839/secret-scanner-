/**
 * patterns.js — SecretSentinel custom detection rules
 * All patterns used by Custom Regex Scanner, Keyword Scanner, and Aho-Corasick
 */

// ─── Custom Regex Rules ───────────────────────────────────────────────────────
const CUSTOM_REGEX_RULES = [
  {
    id: 'internal-api-token',
    description: 'SecretSentinel internal API token',
    regex: /SSENT-[A-Z0-9]{32}/g,
    severity: 'CRITICAL',
    confidence: 95,
  },
  {
    id: 'custom-jwt',
    description: 'Custom JWT with known prefix',
    regex: /eyJhbGc[A-Za-z0-9_-]{50,}/g,
    severity: 'HIGH',
    confidence: 85,
  },
  {
    id: 'aws-access-key',
    description: 'AWS Access Key ID',
    // AKIA prefix = much more precise, covers real + test keys of any length
    regex: /AKIA[0-9A-Z]{8,20}/g,
    severity: 'CRITICAL',
    confidence: 90,
  },
  {
    id: 'aws-secret-key',
    description: 'AWS Secret Access Key — keyword-anchored',
    // Anchored to keyword so no false positives on random 40-char strings
    regex: /(?:aws_secret|aws_secret_access_key|secret_access_key)\s*[=:]\s*['"`]?([A-Za-z0-9/+=]{16,})['"`]?/gi,
    severity: 'CRITICAL',
    confidence: 85,
  },
  {
    id: 'github-pat',
    description: 'GitHub Personal Access Token',
    regex: /ghp_[A-Za-z0-9]{20,}/g,
    severity: 'CRITICAL',
    confidence: 99,
  },
  {
    id: 'github-oauth',
    description: 'GitHub OAuth Token',
    regex: /gho_[A-Za-z0-9]{36}/g,
    severity: 'CRITICAL',
    confidence: 99,
  },
  {
    id: 'stripe-secret',
    description: 'Stripe Secret Key (live or test)',
    // covers sk_live_ and sk_test_
    regex: /sk_(live|test)_[A-Za-z0-9]{12,}/g,
    severity: 'CRITICAL',
    confidence: 99,
  },
  {
    id: 'stripe-publishable',
    description: 'Stripe Publishable Key',
    regex: /pk_(live|test)_[A-Za-z0-9]{12,}/g,
    severity: 'MEDIUM',
    confidence: 99,
  },
  {
    id: 'google-api-key',
    description: 'Google API Key',
    regex: /AIza[0-9A-Za-z_-]{30,}/g,
    severity: 'HIGH',
    confidence: 99,
  },
  {
    id: 'slack-token',
    description: 'Slack Bot/User Token',
    regex: /xox[baprs]-[0-9A-Za-z]{10,48}/g,
    severity: 'HIGH',
    confidence: 99,
  },
  {
    id: 'private-key-header',
    description: 'PEM Private Key',
    regex: /-----BEGIN\s+(RSA |EC |OPENSSH )?PRIVATE KEY-----/g,
    severity: 'CRITICAL',
    confidence: 99,
  },
  {
    id: 'generic-secret-assignment',
    description: 'Generic secret in assignment',
    // expanded to cover awsKey, awsSecret, adminPwd, ec2Key etc.
     regex: /(?:secret|password|passwd|pwd|token|api_key|apikey|auth_key|aws_?key|aws_?secret|private_?key|ec2_?private_?key|ec2_?key|admin_?pwd|admin_?pass|jwt_?secret|db_?pass(?:word)?)\s*[:=]\s*(['"\`]?)([^'"\`\s]{6,})\1/gi,
      severity: 'HIGH',
    confidence: 70,
  },
  {
    id: 'db-connection-string',
    description: 'Database connection string with credentials',
    regex: /(?:mongodb|mysql|postgres|postgresql|redis):\/\/[^:]+:[^@]+@[^\s'"]+/gi,
    severity: 'CRITICAL',
    confidence: 95,
  },
  {
    id: 'pdo-constructor',
    description: 'PHP PDO constructor with hardcoded credentials',
    // Catches: new PDO("dsn", "username", "password")
    // Multiline — matches up to 5 lines between parens
    regex: /new\s+PDO\s*\([^)]*['"](mysql|pgsql|sqlite)[^'"]*['"][^)]*['"]([^'"]{2,})['"][^)]*['"]([^'"]{4,})['"]/gis,
    severity: 'CRITICAL',
    confidence: 95,
  },
  {
    id: 'bearer-token',
    description: 'Bearer token in Authorization header',
    // Catches: Authorization: Bearer <token>  or  Bearer eyJ...
    regex: /(?:Authorization|auth)\s*[:=]\s*Bearer\s+([A-Za-z0-9._\-+/]{20,})/gi,
    severity: 'CRITICAL',
    confidence: 90,
  },
  {
    id: 'jwt-token',
    description: 'JWT token (three base64 segments)',
    regex: /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{4,}/g,
    severity: 'HIGH',
    confidence: 85,
  },
  {
    id: 'ansible-ssh-key-file',
    description: 'Ansible SSH private key file reference',
    regex: /ansible_ssh_private_key_file\s*=\s*(~?\/[^\s]+\.(?:pem|rsa|key)|~\/.ssh\/[^\s]+)/g,
    severity: 'HIGH',
    confidence: 85,
  },
  {
    id: 'vault-token',
    description: 'HashiCorp Vault token',
    // hvs. = Vault Service token, hvb. = batch token, s. = old format
    regex: /(?:vault_?token|VAULT_TOKEN)\s*[:=]\s*['"`]?(hvs\.[A-Za-z0-9._-]{20,}|hvb\.[A-Za-z0-9._-]{20,}|s\.[A-Za-z0-9]{20,})['"`]?/gi,
    severity: 'CRITICAL',
    confidence: 95,
  },
  {
    id: 'http-header-secret',
    description: 'Secret value in HTTP header (log file)',
    // Catches: Stripe-Key: sk_... ,  X-Api-Key: ..., etc in log files
    regex: /(?:Stripe-Key|X-Api-Key|Api-Key|X-Auth-Token|X-Secret)\s*:\s*([A-Za-z0-9._\-]{16,})/gi,
    severity: 'CRITICAL',
    confidence: 90,
  },
  {
  id: 'env-style-secret',
  description: 'Environment variable with sensitive name and assigned value',
  regex: /(?:^|export\s+)([A-Z0-9_]*(?:PASSWORD|SECRET|KEY|TOKEN|PWD|PASS)[A-Z0-9_]*)\s*=\s*(['"`]?)([^\s'"`#]{6,})\2/gm,
  severity: 'HIGH',
  confidence: 75,
},
  {
    id: 'sendgrid-key',
    description: 'SendGrid API Key',
    regex: /SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}/g,
    severity: 'HIGH',
    confidence: 99,
  },
  {
    id: 'twilio-key',
    description: 'Twilio API Key',
    regex: /SK[0-9a-fA-F]{32}/g,
    severity: 'HIGH',
    confidence: 90,
  },
];

// ─── Keyword Scanner Rules ────────────────────────────────────────────────────
// Used by both Keyword Scanner and Aho-Corasick engine
const SENSITIVE_KEYWORDS = [
  // Credential keywords
  'password', 'passwd', 'pwd', 'passphrase',
  'secret', 'secret_key', 'secretkey',
  'api_key', 'apikey', 'api_secret',
  'auth_key', 'auth_token', 'authtoken',
  'access_key', 'access_token', 'accesstoken',
  'private_key', 'privatekey',
  'client_secret', 'client_id',
  'old_password', 'temp_api_key', 'prev_password', 'backup_key',
'stripe_secret_key', 

  // AWS — expanded
  'aws_secret', 'aws_access_key', 'aws_session_token',
  'aws_secret_access_key', 'aws_secret_key',
  'awskey', 'awssecret', 'aws_key',

  // EC2 / cloud infra
  'ec2_private_key', 'ec2_key', 'ec2key',

  // Database
  'db_password', 'database_password', 'db_pass',
  'db_user', 'db_username', 'connection_string',

  // Cloud providers
  'azure_client_secret', 'gcp_credentials',

  // Services
  'stripe_secret', 'stripe_key', 'stripe_secret_key',
  'sendgrid_key', 'mailgun_key',
  'twilio_auth', 'slack_token',
  'github_token', 'gitlab_token',          // catches JWT_SECRET= env form (already present but verify)
'ec2_private_key',

  // Generic sensitive
  'encryption_key', 'signing_key', 'master_key',
  'bearer_token', 'refresh_token', 'id_token',
  'ssh_key', 'rsa_key', 'pem_key',
  'webhook_secret', 'jwt_secret',

  // Camel/mixed case variants common in JS
  'adminpwd', 'adminpass', 'adminpassword',
  // Vault
  'vault_token', 'vault_addr', 'vault_secret',
  // Ansible
  'ansible_ssh_private_key_file', 'ansible_become_pass',
  // HTTP headers
  'authorization', 'x-api-key', 'x-auth-token',
  // PHP/DB
  'db_host', 'db_name', 'db_port',
];

// ─── Fuzzy Match Targets ──────────────────────────────────────────────────────
// Canonical forms — fuzzy matching will catch obfuscated variants
const FUZZY_TARGETS = [
  'password', 'secret', 'apikey', 'token',
  'credential', 'private', 'passwd',
];

// ─── Entropy Config ───────────────────────────────────────────────────────────
const ENTROPY_CONFIG = {
  minLength: 20,       // ignore strings shorter than this
  maxLength: 500,      // ignore very long strings (likely minified code)
  threshold: 4.2,      // Shannon entropy threshold (0–8 scale)
  // File types to skip entropy analysis on
  skipExtensions: [
    '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico',
    '.woff', '.woff2', '.ttf', '.eot',
    '.min.js', '.min.css',
    'package-lock.json', 'yarn.lock', 'pnpm-lock.yaml',
    '.map',
  ],
};

// ─── Severity → Score mapping ─────────────────────────────────────────────────
const SEVERITY_SCORE = {
  CRITICAL: 90,
  HIGH: 70,
  MEDIUM: 50,
  LOW: 30,
};

module.exports = {
  CUSTOM_REGEX_RULES,
  SENSITIVE_KEYWORDS,
  FUZZY_TARGETS,
  ENTROPY_CONFIG,
  SEVERITY_SCORE,
};
