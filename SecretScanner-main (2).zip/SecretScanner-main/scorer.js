// // scorer.js — Computes rule_score, ai_score, risk_score, risk_level, ai_justification

// const SEVERITY_WEIGHTS = { CRITICAL: 40, HIGH: 25, MEDIUM: 15, LOW: 5 };
// const PRIVILEGE_WEIGHTS = { Admin: 30, High: 25, Medium: 15, Low: 5 };
// const EXPOSURE_FACTOR   = 0.5;   // points per day exposed (cap 30)
// const PUBLIC_BONUS      = 10;    // extra points if repo is public

// /**
//  * Rule Score (0–100)
//  * Based on: severity, privilege, exposure days, public visibility
//  * 
//  */
// function inferProductionScore(finding) {
//   let score = 0;

//   const file   = (finding.File   || "").toLowerCase();
//   const repo   = (finding.repo   || "").toLowerCase();
//   const commit = (finding.Message|| "").toLowerCase();

//   // File path — strongest signal, +2 per prod match
//   if (PROD_PATH_PATTERNS.some(p => file.includes(p))) score += 2;
//   if (DEV_PATH_PATTERNS.some(p => file.includes(p)))  score -= 3; // dev path is strong negative

//   // Repo name — medium signal
//   if (["backend","api","service","platform","infra","core"].some(p => repo.includes(p))) score += 1;
//   if (["lab","sandbox","demo","poc","test"].some(p => repo.includes(p))) score -= 2;

//   // Commit message — weak signal
//   if (["deploy","release","hotfix","launch"].some(p => commit.includes(p))) score += 1;
//   if (["wip","test","temp","draft","debug"].some(p => commit.includes(p))) score -= 1;

//   // Map combined score to a bonus/penalty for calcRuleScore
//   if (score >= 3)  return 10;   // strong production signal
//   if (score >= 1)  return 5;    // mild production signal
//   if (score === 0) return 0;    // unknown
//   if (score <= -2) return -10;  // strong dev/test signal
//   return -5;                    // mild dev signal
// }
// function calcRuleScore(finding) {
//   const sev  = SEVERITY_WEIGHTS[finding.severity]  ?? 0;
//   const priv = PRIVILEGE_WEIGHTS[finding.privilege] ?? 0;
//   const exp  = Math.min(finding.exposure_days * EXPOSURE_FACTOR, 30);
//   const pub  = finding.repo_visibility === "Public" ? PUBLIC_BONUS : 0;
//   const stagingAdjustment = inferProductionScore(finding);
// return Math.round(sev + priv + exp + pub + stagingAdjustment + confPenalty);
//   // return Math.min(Math.round(sev + priv + exp + pub), 100);
// }

// /**
//  * AI Score (0–100)
//  * Weighted blend of confidence, multi-detector bonus, entropy, comment penalty
//  */
// function calcAIScore(finding) {
//   const base      = finding.confidence;                       // 0-100
//   const multiBonus = finding.multiDetector ? 5 : 0;
//   const detSrc    = finding.sources.length > 1 ? 5 : 0;      // corroboration
//   const entropy   = Math.min((finding.Entropy / 5) * 20, 20); // normalise to 20
//   const commentPenalty = finding.inComment ? -15 : 0;
//   return Math.min(Math.round(base + multiBonus + detSrc + entropy + commentPenalty), 100);
// }

// /**
//  * Risk Score (0–100)
//  * Weighted composite: 50% rule score + 50% ai score, then capped
//  */
// function calcRiskScore(ruleScore, aiScore) {
//   return Math.min(Math.round(ruleScore * 0.5 + aiScore * 0.5), 100);
// }

// /**
//  * Risk Level label
//  */
// function calcRiskLevel(riskScore) {
//   if (riskScore >= 85) return "CRITICAL";
//   if (riskScore >= 65) return "HIGH";
//   if (riskScore >= 45) return "MEDIUM";
//   return "LOW";
// }

// /**
//  * AI Justification — human-readable sentence
//  */
// function buildJustification(finding, ruleScore, aiScore, riskScore, riskLevel) {
//   const parts = [];

//   // Secret type & location
//   parts.push(`${finding.secret_type} detected in '${finding.File}' at line ${finding.StartLine}.`);

//   // Severity & privilege context
//   parts.push(`Severity is ${finding.severity} with ${finding.privilege}-level privilege.`);

//   // Exposure
//   parts.push(`Secret has been publicly exposed for ${finding.exposure_days} day(s).`);

//   // Confidence
//   const confLabel = finding.confidence >= 85 ? "high" : finding.confidence >= 70 ? "moderate" : "low";
//   parts.push(`Detector confidence is ${confLabel} (${finding.confidence}%).`);

//   // Multi-source corroboration
//   if (finding.sources.length > 1) {
//     parts.push(`Corroborated by ${finding.sources.length} scanners (${finding.sources.join(", ")}).`);
//   }

//   // Composite verdict
//   parts.push(`Composite risk score: ${riskScore}/100 → Level: ${riskLevel}. Immediate rotation and git-history purge recommended.`);

//   return parts.join(" ");
// }

// /**
//  * Main scoring entry point
//  * @param {Array} findings — raw JSON array from scan-results
//  * @returns {Array} scored findings
//  */
// function scoreFindings(findings) {
//   return findings.map((f, idx) => {
//     const ruleScore = calcRuleScore(f);
//     const aiScore   = calcAIScore(f);
//     const riskScore = calcRiskScore(ruleScore, aiScore);
//     const riskLevel = calcRiskLevel(riskScore);
//     const aiJustification = buildJustification(f, ruleScore, aiScore, riskScore, riskLevel);

//     return {
//       index: idx + 1,
//       file: f.File,
//       ruleId: f.RuleID,
//       secretType: f.secret_type,
//       severity: f.severity,
//       privilege: f.privilege,
//       exposureDays: f.exposure_days,
//       confidence: f.confidence,
//       status: f.status,
//       rule_score: ruleScore,
//       ai_score: aiScore,
//       risk_score: riskScore,
//       risk_level: riskLevel,
//       ai_justification: aiJustification,
//     };
//   });
// }

// module.exports = { scoreFindings };
// scorer.js — Computes rule_score, ai_score, risk_score, risk_level, ai_justification

// WEIGHT CHANGELOG
// v1 (Week 2): Initial guesses
// v2 (Week 3 pass-1): AI score rescaled, comment penalty increased, thresholds shifted
// v3 (Week 3 pass-2): Privilege weights rebalanced, exposure cap split by visibility,
//                     inComment kills rule_score inflation, dev/test path penalty added
// v4 (Week 3 pass-3): inferProductionScore() replaces flat prodBonus/devPenalty —
//                     now combines file path + repo name + commit message signals.
//                     PUBLIC_BONUS split: CRITICAL secrets +20, others +15.
//                     CRITICAL threshold lowered back to 85.
//                     Accuracy: 45% → 63% (pass-1) → 72% (pass-2) → ~85% (pass-3)

const RESET  = "\x1b[0m";
const BOLD   = "\x1b[1m";
const YELLOW = "\x1b[33m";

// ─── Weight Tables ───────────────────────────────────────────────────────────

const SEVERITY_WEIGHTS  = { CRITICAL: 35, HIGH: 22, MEDIUM: 12, LOW: 5 };
const PRIVILEGE_WEIGHTS = { Admin: 25, High: 15, Medium: 10, Low: 5 };
const EXPOSURE_FACTOR   = 0.5;
const PUBLIC_BONUS_CRITICAL = 20;   // extra points for CRITICAL secrets in public repos
const PUBLIC_BONUS_DEFAULT  = 15;   // extra points for other severities in public repos

// ─── Production / Dev Path Patterns ─────────────────────────────────────────
// ADD NEW PATTERNS HERE as you discover more from real scan data

const PROD_PATH_PATTERNS = [
  "prod", "production", ".env.production", ".env.prod",
  "terraform", "terraform.tfvars", "k8s", "kubernetes",
  "infra", "ansible", "deploy", "dockerfile", "docker-compose",
  "ci/", ".github/workflows", "gitlab-ci", "backup", "release"
];

const DEV_PATH_PATTERNS = [
  "test", "tests", "spec", "fixture", "mock", "seed",
  ".env.test", ".env.dev", ".env.local", ".env.example",
  "dev", "staging", "sandbox", "demo", "sample", "example",
  "__tests__", "jest", "cypress"
];

// ─── Production Stage Inference ──────────────────────────────────────────────
// Combines file path + repo name + commit message to infer prod vs dev.
// Returns a bonus (positive) or penalty (negative) to feed into calcRuleScore.

function inferProductionScore(finding) {
  let score = 0;

  const file   = (finding.File    || "").toLowerCase();
  const repo   = (finding.repo    || "").toLowerCase();
  const commit = (finding.Message || "").toLowerCase();

  // File path — strongest signal (+2 prod hit, -3 dev hit)
  if (PROD_PATH_PATTERNS.some(p => file.includes(p))) score += 2;
  if (DEV_PATH_PATTERNS.some(p => file.includes(p)))  score -= 3;

  // Repo name — medium signal
  if (["backend","api","service","platform","infra","core"].some(p => repo.includes(p))) score += 1;
  if (["lab","sandbox","demo","poc","test"].some(p => repo.includes(p)))                 score -= 2;

  // Commit message — weak signal
  if (["deploy","release","hotfix","launch"].some(p => commit.includes(p))) score += 1;
  if (["wip","test","temp","draft","debug"].some(p => commit.includes(p)))  score -= 1;

  // Map combined score → rule_score adjustment
  if (score >= 3)  return 10;   // strong production signal   → +10
  if (score >= 1)  return 5;    // mild production signal     → +5
  if (score === 0) return 0;    // unknown                    → no change
  if (score <= -2) return -10;  // strong dev/test signal     → -10
  return -5;                    // mild dev signal             → -5
}

// ─── Rule Score (0–100) ───────────────────────────────────────────────────────
// Based on: severity, privilege, exposure days, public visibility, prod/dev stage

function calcRuleScore(finding) {
  const sev  = SEVERITY_WEIGHTS[finding.severity]  ?? 0;
  const priv = PRIVILEGE_WEIGHTS[finding.privilege] ?? 0;

  // Public repos get higher exposure cap — more urgency to rotate fast
  const expCap = finding.repo_visibility === "Public" ? 30 : 20;
  const exp    = Math.min(finding.exposure_days * EXPOSURE_FACTOR, expCap);

  // Public bonus: heavier for CRITICAL secrets (AWS keys etc.), normal for others
  const pub = finding.repo_visibility === "Public"
    ? (finding.severity === "CRITICAL" ? PUBLIC_BONUS_CRITICAL : PUBLIC_BONUS_DEFAULT)
    : 0;

  // Production stage adjustment — replaces old flat prodBonus/devPenalty
  const stageAdjustment = inferProductionScore(finding);

  // Low confidence penalty
  const confPenalty = finding.confidence < 60 ? -10 : 0;

  let score = Math.round(sev + priv + exp + pub + stageAdjustment + confPenalty);

  // inComment hard cap — no comment-block secret should exceed HIGH boundary
  if (finding.inComment) score = Math.min(score, 40);

  return Math.min(score, 100);
}

// ─── AI Score (0–100) ─────────────────────────────────────────────────────────
// Weighted blend of confidence, multi-detector bonus, entropy, comment penalty.
// Base is scaled to 75 max to prevent inflation from stacking bonuses.

function calcAIScore(finding) {
  const base         = finding.confidence * 0.75;          // 0–75 max (was 0–100, caused inflation)
  const multiBonus   = finding.multiDetector ? 5 : 0;
  const detSrc       = finding.sources.length > 1 ? 5 : 0;
  const entropy      = Math.min((finding.Entropy / 5) * 10, 10); // 0–10 max (was 0–20)
  const commentPenalty = finding.inComment ? -25 : 0;            // was -15, increased
  return Math.min(Math.round(base + multiBonus + detSrc + entropy + commentPenalty), 100);
}

// ─── Risk Score (0–100) ───────────────────────────────────────────────────────
// Rule score carries slightly more weight — it uses hard metadata.
// AI score is secondary — it uses confidence + entropy signals.

function calcRiskScore(ruleScore, aiScore) {
  return Math.min(Math.round(ruleScore * 0.55 + aiScore * 0.45), 100);
}

// ─── Risk Level ───────────────────────────────────────────────────────────────

function calcRiskLevel(riskScore) {
  if (riskScore >= 85) return "CRITICAL";
  if (riskScore >= 68) return "HIGH";
  if (riskScore >= 48) return "MEDIUM";
  return "LOW";
}

// ─── AI Justification ────────────────────────────────────────────────────────

function buildJustification(finding, ruleScore, aiScore, riskScore, riskLevel) {
  const parts = [];

  parts.push(`${finding.secret_type} detected in '${finding.File}' at line ${finding.StartLine}.`);
  parts.push(`Severity is ${finding.severity} with ${finding.privilege}-level privilege.`);
  parts.push(`Secret has been publicly exposed for ${finding.exposure_days} day(s).`);

  const confLabel = finding.confidence >= 85 ? "high" : finding.confidence >= 70 ? "moderate" : "low";
  parts.push(`Detector confidence is ${confLabel} (${finding.confidence}%).`);

  if (finding.sources.length > 1) {
    parts.push(`Corroborated by ${finding.sources.length} scanners (${finding.sources.join(", ")}).`);
  }

  // Production stage context in justification
  const file   = (finding.File    || "").toLowerCase();
  const repo   = (finding.repo    || "").toLowerCase();
  const isProd = PROD_PATH_PATTERNS.some(p => file.includes(p)) ||
                 ["backend","api","service","platform","infra","core"].some(p => repo.includes(p));
  const isDev  = DEV_PATH_PATTERNS.some(p => file.includes(p)) ||
                 ["lab","sandbox","demo","poc","test"].some(p => repo.includes(p));

  if (isProd)          parts.push(`File is in a production-path context — elevated risk.`);
  else if (isDev)      parts.push(`File is in a development/test context — reduced risk.`);
  else                 parts.push(`Deployment context is unknown.`);

  if (finding.inComment) parts.push(`Secret found in a comment block — may be inactive.`);

  parts.push(`Composite risk score: ${riskScore}/100 → Level: ${riskLevel}. Immediate rotation and git-history purge recommended.`);

  return parts.join(" ");
}

// ─── Main Entry Point ─────────────────────────────────────────────────────────

function scoreFindings(findings) {
  return findings.map((f, idx) => {
    const ruleScore       = calcRuleScore(f);
    const aiScore         = calcAIScore(f);
    const riskScore       = calcRiskScore(ruleScore, aiScore);
    const riskLevel       = calcRiskLevel(riskScore);
    const aiJustification = buildJustification(f, ruleScore, aiScore, riskScore, riskLevel);

    return {
      id:               f.id, 
      file:             f.File,
      ruleId:           f.RuleID,
      secretType:       f.secret_type,
      severity:         f.severity,
      privilege:        f.privilege,
      exposureDays:     f.exposure_days,
      confidence:       f.confidence,
      status:           f.status,
      repo:             f.repo,
      rule_score:       ruleScore,
      ai_score:         aiScore,
      risk_score:       riskScore,
      risk_level:       riskLevel,
      ai_justification: aiJustification,
    };
  });
}

module.exports = { scoreFindings };
