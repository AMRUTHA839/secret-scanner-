require('dotenv').config();

const { createClient } = require('@supabase/supabase-js');
const ws = require('ws');

let supabase = null;
if (process.env.SUPABASE_URL && process.env.SUPABASE_KEY) {
  supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY, {
    realtime: { transport: ws }
  });
} else {
  console.warn('[supabase] SUPABASE_URL/KEY not set — running without Supabase.');
}

module.exports = supabase;