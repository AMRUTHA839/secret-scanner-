"""
github_visibility.py
=====================
Resolves whether a GitHub repo is Public or Private from its URL.
Uses the GitHub API — no token needed for public repos.
With a token, also works for private repos you have access to.

Usage:
    python github_visibility.py https://github.com/owner/repo
    # → Public  or  Private  or  Unknown
"""

import re
import json
import urllib.request
import urllib.error


def parse_github_url(url: str):
    """
    Extract owner and repo name from a GitHub URL.
    Handles:
      https://github.com/owner/repo
      https://github.com/owner/repo/tree/branch
      git@github.com:owner/repo.git
    Returns (owner, repo) or (None, None).
    """
    patterns = [
        r"github\.com[:/]([^/]+)/([^/.\s]+?)(?:\.git)?(?:/|$)",
    ]
    for pat in patterns:
        m = re.search(pat, url)
        if m:
            return m.group(1), m.group(2)
    return None, None


def check_visibility(github_url: str, token: str = None) -> str:
    """
    Check if a GitHub repo is Public or Private.

    Args:
        github_url: full GitHub repo URL
        token:      GitHub personal access token (optional, needed for private repos)

    Returns:
        "Public", "Private", or "Unknown"
    """
    owner, repo = parse_github_url(github_url)
    if not owner or not repo:
        print(f"[GitHub] Could not parse URL: {github_url}")
        return "Unknown"

    api_url = f"https://api.github.com/repos/{owner}/{repo}"
    headers = {"Accept": "application/vnd.github+json",
               "User-Agent": "SecretSentinel-Pipeline/1.0"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        req = urllib.request.Request(api_url, headers=headers)
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode())
            is_private = data.get("private", True)
            visibility = "Private" if is_private else "Public"
            print(f"[GitHub] {owner}/{repo} → {visibility}")
            return visibility
    except urllib.error.HTTPError as e:
        if e.code == 404:
            # Could be private (unauthenticated can't see private repos)
            print(f"[GitHub] {owner}/{repo} → Private (or not found)")
            return "Private"
        print(f"[GitHub] HTTP error {e.code} for {api_url}")
        return "Unknown"
    except Exception as ex:
        print(f"[GitHub] Could not reach API: {ex}")
        return "Unknown"


def resolve_visibility_for_repos(repo_urls: list, token: str = None) -> dict:
    """
    Resolve visibility for multiple repo URLs.
    Returns dict: repo_name → "Public" | "Private" | "Unknown"
    """
    result = {}
    for url in repo_urls:
        _, repo = parse_github_url(url)
        if repo:
            result[repo] = check_visibility(url, token)
    return result


if __name__ == "__main__":
    import sys
    url   = sys.argv[1] if len(sys.argv) > 1 else ""
    token = sys.argv[2] if len(sys.argv) > 2 else None
    if url:
        print(check_visibility(url, token))
    else:
        print("Usage: python github_visibility.py <github_url> [token]")
