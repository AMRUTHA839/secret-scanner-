/**
 * test-scan.js — SecretSentinel scanner
 *
 * USAGE
 * ─────
 *   # Pass GitHub URLs directly:
 *   node test-scan.js https://github.com/owner/repo1 https://github.com/owner/repo2
 *
 *   # For private repos, set token first:
 *   set GITHUB_TOKEN=ghp_xxxx       (Windows)
 *   export GITHUB_TOKEN=ghp_xxxx    (Mac/Linux)
 *   node test-scan.js https://github.com/owner/private-repo
 *
 *   # No args — falls back to DEFAULT_REPOS below:
 *   node test-scan.js--
 */
'use strict';
const crypto = require('crypto');

function generateFindingId(finding) {
  const key = [
    finding.File        || '',
    finding.RuleID      || '',
    finding.StartLine   || '',
    finding.Secret      || finding.Match || '',
    finding.Fingerprint || ''
  ].join('|');
  const hash = crypto.createHash('sha256').update(key).digest('hex');
  const num  = parseInt(hash.slice(0, 5), 16) % 90000 + 10000; // 5 digits: 10000–99999
  return `SS-${num}`;
}

const { scanRepo } = require('./services/scanner');
const fs    = require('fs');
const os    = require('os');
const path  = require('path');
const { execSync, spawnSync } = require('child_process');

// ── CHANGE 1: Default repos as GitHub URLs (replace old local paths) ──────────
const DEFAULT_REPOS = [
  'https://github.com/SecretScanningLab/payment-api',
  'https://github.com/SecretScanningLab/cloud-backend',
  'https://github.com/SecretScanningLab/legacy-php-crm',
];

// Optional GitHub token for private repos / higher API rate limit
const GITHUB_TOKEN = process.env.GITHUB_TOKEN || '';

const PRIVILEGE_ICON = { Admin: '🔴', High: '🟠', Medium: '🟡', Low: '🟢' };
const SEVERITY_ICON  = { CRITICAL: '🔴', HIGH: '🟠', MEDIUM: '🟡', LOW: '🟢' };

// ── CHANGE 2: Parse a GitHub URL into owner/repo/cloneUrl ─────────────────────
function parseGitHubUrl(url) {
  const clean = url.trim().replace(/\.git$/, '').replace(/\/tree\/.*$/, '').replace(/\/$/, '');
  const m = clean.match(/github\.com[:/]([^/]+)\/([^/]+)/);
  if (!m) throw new Error(`Cannot parse GitHub URL: ${url}`);
  const owner = m[1];
  const repo  = m[2];
  const cloneUrl = GITHUB_TOKEN
    ? `https://${GITHUB_TOKEN}@github.com/${owner}/${repo}.git`
    : `https://github.com/${owner}/${repo}.git`;
  return { owner, repo, cloneUrl, displayUrl: `https://github.com/${owner}/${repo}` };
}

// ── CHANGE 3: Resolve real visibility via GitHub API ──────────────────────────
function resolveVisibility(owner, repo) {
  const apiUrl = `https://api.github.com/repos/${owner}/${repo}`;
  const args = ['-s', '-H', 'Accept: application/vnd.github+json',
                      '-H', 'User-Agent: SecretSentinel/1.0'];
  if (GITHUB_TOKEN) {
    args.push('-H', `Authorization: Bearer ${GITHUB_TOKEN}`);
  }
  args.push(apiUrl);

  try {
    const result = spawnSync('curl', args, { encoding: 'utf8', timeout: 10000 });
    if (result.error || result.status !== 0) return 'Unknown';
    const data = JSON.parse(result.stdout);
    if (data.message === 'Not Found') return 'Private';
    return data.private === false ? 'Public' : 'Private';
  } catch {
    return 'Unknown';
  }
}

// ── CHANGE 4: Clone repo into a temp folder ───────────────────────────────────
function cloneRepo(cloneUrl, repoName) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), `secretscan-${repoName}-`));
  console.log(`[Clone] ${repoName} → ${tmpDir}`);
  execSync(`git clone --depth=50 "${cloneUrl}" "${tmpDir}"`, { stdio: 'pipe', timeout: 120000 });
  return tmpDir;
}

function cleanup(dir) {
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch {}
}

async function main() {
  // ── CHANGE 5: Read URLs from CLI args, fallback to DEFAULT_REPOS ─────────────
  const rawArgs = process.argv.slice(2).filter(a => a.startsWith('http'));
  const urls    = rawArgs.length > 0 ? rawArgs : DEFAULT_REPOS;

  console.log(`\nSecretSentinel — scanning ${urls.length} repo(s)\n`);

  const allFindings = [];
  const repoMetaMap = {};
  const failedUrls = [];

  for (const url of urls) {
    let parsed;
    try {
      parsed = parseGitHubUrl(url);
    } catch (err) {
      console.error(`[Error] ${err.message}`);
      failedUrls.push({ url, reason: err.message });
      continue;
    }

    const { owner, repo, cloneUrl, displayUrl } = parsed;

    console.log('\n' + '='.repeat(65));
    console.log('Scanning: ' + displayUrl);
    console.log('='.repeat(65));

    // ── CHANGE 6: Get real visibility before scanning ─────────────────────────
    console.log(`[Visibility] Checking ${owner}/${repo}...`);
    const visibility = resolveVisibility(owner, repo);
    console.log(`[Visibility] → ${visibility}`);

    // Clone
    let tmpDir;
    try {
      tmpDir = cloneRepo(cloneUrl, repo);
    } catch (err) {
      console.error(`[Clone Error] ${err.message}`);
      failedUrls.push({ url: displayUrl, reason: `Clone failed: ${err.message}` });
      continue;
    }

    // Scan
    let result;
    try {
      result = await scanRepo(tmpDir);
    } catch (err) {
      console.error(`[Scan Error] ${err.message}`);
      failedUrls.push({ url: displayUrl, reason: `Scan failed: ${err.message}` });
      cleanup(tmpDir);
      continue;
    }

   // ── CHANGE 7: Patch real visibility + fix links + add scan timestamp ──────
const scannedAt = new Date().toISOString(); // ← add this

    for (const f of result.findings) {
  f.repo            = repo;
  f.repo_visibility = visibility;
  f.scannedAt       = scannedAt;
  if (f.Link && !f.Link.startsWith('http')) {
    f.Link = `${displayUrl}/blob/${f.Commit || 'HEAD'}/${f.File}#L${f.StartLine}`;
  }
}

    const critCount = result.findings.filter(x => x.severity === 'CRITICAL').length;
    const highCount = result.findings.filter(x => x.severity === 'HIGH').length;
    const scanStatus = critCount ? 'CRITICAL' : highCount ? 'HIGH' : result.summary.total ? 'MEDIUM' : 'CLEAN';

    if (!repoMetaMap[repo]) repoMetaMap[repo] = { scanHistory: [] };
    const entry = {
      date: scannedAt,
      durationMs: result.durationMs,
      findings: result.summary.total,
      status: scanStatus,
      files: result.scannedFiles,
    };
    repoMetaMap[repo] = {
      name: repo,
      org: owner,
      url: displayUrl,
      visibility,
      scannedAt,
      durationMs: result.durationMs,
      scannedFiles: result.scannedFiles,
      defaultBranch: 'main',
      depth: 50,
      schedule: 'Manual',
      scanHistory: [entry, ...(repoMetaMap[repo].scanHistory || [])].slice(0, 10),
    };

    // Print summary (unchanged from original)
    console.log('\nFiles scanned   : ' + result.scannedFiles);
    console.log('Files skipped   : ' + (result.skippedFiles || 0));
    console.log('Total findings  : ' + result.summary.total);
    console.log('Duration        : ' + result.durationMs + 'ms');
    console.log('Repo visibility : ' + visibility);

    console.log('\nBy Severity:');
    console.log(JSON.stringify(result.summary.bySeverity, null, 2));

    console.log('\nBy Detector:');
    console.log(JSON.stringify(result.summary.byDetector, null, 2));

    console.log('\n--- Findings ---\n');
    result.findings.forEach((f, i) => {
      const sevIcon  = SEVERITY_ICON[f.severity]  || '⚪';
      const privIcon = PRIVILEGE_ICON[f.privilege] || '⚪';

      console.log(`[${i + 1}] ${sevIcon} ${f.severity} — ${f.RuleID}`);
      console.log(`    Secret Type   : ${f.secret_type}`);
      console.log(`    File          : ${f.File}  (Lines ${f.StartLine}–${f.EndLine})`);
      console.log(`    Match         : ${f.Match}`);
      console.log(`    Secret        : ${f.Secret ? f.Secret.substring(0, 35) + (f.Secret.length > 35 ? '...' : '') : ''}`);
      console.log(`    Entropy       : ${f.Entropy}`);
      console.log(`    Detector      : ${f.detector}  (Confidence: ${f.confidence}%)`);
      console.log(`    In comment    : ${f.inComment ? 'YES ⚠️' : 'no'}`);
      console.log(`    ${privIcon} Privilege  : ${f.privilege}`);
      console.log(`    Status        : ${f.status}`);
      console.log(`    Repo visible  : ${f.repo_visibility}`);
      console.log(`    Exposure days : ${f.exposure_days > 0 ? f.exposure_days + ' days' : 'N/A (no git history)'}`);
      if (f.Author)  console.log(`    Author        : ${f.Author} <${f.Email}>`);
      if (f.Commit)  console.log(`    Commit        : ${f.Commit}`);
      if (f.Date)    console.log(`    Date          : ${f.Date}`);
      if (f.Message) console.log(`    Message       : ${f.Message}`);
      if (f.Link)    console.log(`    Link          : ${f.Link}`);
      console.log(`    Fingerprint   : ${f.Fingerprint}`);
      console.log('');
    });

    allFindings.push(...result.findings);
    cleanup(tmpDir);
  }

  // Save scan-results.json — identical schema to before
  const output = allFindings.map(f => ({
    id:              generateFindingId(f),
    RuleID:          f.RuleID,
    Description:     f.Description,
    StartLine:       f.StartLine,
    EndLine:         f.EndLine,
    StartColumn:     f.StartColumn,
    EndColumn:       f.EndColumn,
    Match:           f.Match,
    Secret:          f.Secret,
    File:            f.File,
    SymlinkFile:     f.SymlinkFile  || '',
    Commit:          f.Commit       || '',
    Link:            f.Link         || '',
    Entropy:         f.Entropy,
    Author:          f.Author       || '',
    Email:           f.Email        || '',
    commitDate:      f.Date        || '',
    Message:         f.Message      || '',
    Tags:            f.Tags         || [],
    Fingerprint:     f.Fingerprint,
    secret_type:     f.secret_type,
    repo:            f.repo,
    repo_visibility: f.repo_visibility,
    exposure_days:   f.exposure_days,
    privilege:       f.privilege,
    status:          f.status,
    severity:        f.severity,
    confidence:      f.confidence,
    detector:        f.detector,
    scannedAt:       f.scannedAt || new Date().toISOString(),
    inComment:       f.inComment     || false,
    sources:         f.sources       || [f.detector],
    multiDetector:   f.multiDetector || false,
  }));

  fs.writeFileSync('scan-results.json', JSON.stringify(output, null, 2));

  let existingMeta = {};
  try {
    if (fs.existsSync('repo-meta.json')) {
      existingMeta = JSON.parse(fs.readFileSync('repo-meta.json', 'utf8')).repos || {};
    }
  } catch {}
  const mergedMeta = { ...existingMeta };
  for (const [name, meta] of Object.entries(repoMetaMap)) {
    const prev = mergedMeta[name] || {};
    mergedMeta[name] = {
      ...prev,
      ...meta,
      scanHistory: meta.scanHistory || prev.scanHistory || [],
    };
  }
  fs.writeFileSync('repo-meta.json', JSON.stringify({ repos: mergedMeta }, null, 2));

  console.log('\n' + '='.repeat(65));
  console.log('Scan complete. ' + output.length + ' total findings saved to scan-results.json');
  if (failedUrls.length) {
    console.log(`WARNING: ${failedUrls.length}/${urls.length} repo(s) failed to scan:`);
    failedUrls.forEach(f => console.log(`  - ${f.url}: ${f.reason}`));
  }
  console.log('='.repeat(65));

  // If every single URL failed (bad URL, clone error, scan error), this is
  // NOT a clean "0 findings" result — exit nonzero so the server doesn't
  // treat the empty output as a successful scan and overwrite good data.
  if (failedUrls.length === urls.length) {
    console.error('\nAll repos failed to scan — treating this as a failed run.');
    process.exitCode = 1;
  }
}

main().catch(console.error);