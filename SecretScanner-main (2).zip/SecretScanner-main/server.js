/**
 * SecretSentinel â€” server.js
 *
 * HOW TO RUN:
 *   1. Put ALL these files in ONE folder:
 *        server.js
 *        index.html
 *        dashboard-admin.html
 *        dashboard-user.html
 *
 *   2. Open terminal IN that folder and run:
 *        npm install express cors
 *        node server.js
 *
 *   3. Open browser at:  http://localhost:3000
 *
 * LOGIN ACCOUNTS:
 *   admin / admin123  â†’  full dashboard (all tabs + Configuration)
 *   user  / user123   â†’  Findings only
 */

require('dotenv').config();

console.log('SUPABASE_URL:', process.env.SUPABASE_URL);
'use strict';

const express   = require('express');
const cors      = require('cors');
const crypto    = require('crypto');
const path      = require('path');
const fs        = require('fs');
const { spawn } = require('child_process');
const { scoreFindings } = require('./scorer');
const supabase = require('./supabase');

const app  = express();
const PORT = process.env.PORT || 3000;

// â”€â”€â”€ The folder where server.js lives â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const ROOT = __dirname;

// â”€â”€â”€ Helper: read an HTML file and send it â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function sendHtml(res, filename) {
  const filepath = path.join(ROOT, filename);
  if (!fs.existsSync(filepath)) {
    return res.status(404).send(`
      <h2 style="font-family:monospace;color:red">File not found: ${filename}</h2>
      <p style="font-family:monospace">
        Make sure <b>${filename}</b> is in the same folder as <b>server.js</b>.<br><br>
        Current folder: <b>${ROOT}</b><br><br>
        Files found here:<br>
        ${fs.readdirSync(ROOT).map(f => '&nbsp;&nbsp;' + f).join('<br>')}
      </p>
    `);
  }
  res.sendFile(filepath);
}

function readJsonFile(filename, fallback = null) {
  const filepath = path.join(ROOT, filename);
  if (!fs.existsSync(filepath)) return fallback;
  return JSON.parse(fs.readFileSync(filepath, 'utf8'));
}

function normalizeFindings(data) {
  if (Array.isArray(data)) return data.filter(f => f && typeof f === 'object');
  if (!data || typeof data !== 'object') return [];
  if (Array.isArray(data.findings)) return data.findings.filter(f => f && typeof f === 'object');
  if (Array.isArray(data.scored)) return data.scored.filter(f => f && typeof f === 'object');
  return [];
}

function readLatestFindings() {
  // scan-results.json is the single source of truth for "the latest scan".
  // If it exists — even with zero findings — trust it. Don't silently
  // fall back to findings.json / scored-results.json from a *previous*
  // scan just because this scan happened to find nothing.
  const scanResultsPath = path.join(ROOT, 'scan-results.json');
  if (fs.existsSync(scanResultsPath)) {
    try {
      return normalizeFindings(JSON.parse(fs.readFileSync(scanResultsPath, 'utf8')));
    } catch {
      return [];
    }
  }
  // Only fall back if scan-results.json has never been created at all
  // (e.g. server just started and no scan has run yet).
  const candidates = ['findings.json', 'scored-results.json'];
  for (const filename of candidates) {
    try {
      const findings = normalizeFindings(readJsonFile(filename));
      if (findings.length) return findings;
    } catch {}
  }
  return [];
}

function saveFindings(findings) {
  fs.writeFileSync(path.join(ROOT, 'findings.json'), JSON.stringify({ findings }, null, 2));
}

function generateFindingId(finding) {
  const key = [
    finding.File || finding.file || '',
    finding.RuleID || finding.rule || '',
    finding.StartLine || finding.line || '',
    finding.Secret || finding.Match || finding.match || finding.value || '',
    finding.Fingerprint || '',
  ].join('|');
  const hash = crypto.createHash('sha256').update(key).digest('hex');
  const num = parseInt(hash.slice(0, 5), 16) % 90000 + 10000;
  return `SS-${num}`;
}

function inferSecretType(ruleId, desc) {
  const text = `${ruleId || ''} ${desc || ''}`.toLowerCase();
  if (/aws|akia/.test(text)) return 'AWS';
  if (/github|ghp_|gho_/.test(text)) return 'GitHub';
  if (/stripe/.test(text)) return 'Stripe';
  if (/jwt/.test(text)) return 'JWT';
  if (/postgres|mysql|mongo|redis|db-/.test(text)) return 'Database';
  if (/private.?key/.test(text)) return 'Private Key';
  if (/password|secret|api.?key|token/.test(text)) return 'Generic Secret';
  return 'Unknown';
}

function inferPrivilege(secretType, severity) {
  const sev = (severity || 'HIGH').toUpperCase();
  if (/aws|database|private key/i.test(secretType)) return sev === 'CRITICAL' ? 'Admin' : 'High';
  if (sev === 'CRITICAL') return 'High';
  if (sev === 'HIGH') return 'Medium';
  return 'Low';
}

function normalizeAdminFinding(raw, ctx) {
  if (raw.RuleID && (raw.File || raw.file)) {
    const file = raw.File || raw.file || '';
    const ruleId = raw.RuleID || raw.ruleId || raw.rule || 'unknown';
    const match = raw.Match || raw.match || raw.value || '';
    const severity = (raw.severity || 'HIGH').toUpperCase();
    const line = raw.StartLine || raw.line || 1;
    const secretType = raw.secret_type || raw.secretType || inferSecretType(ruleId, raw.Description || raw.desc);
    return {
      ...raw,
      id: raw.id || generateFindingId({ File: file, RuleID: ruleId, StartLine: line, Match: match }),
      RuleID: ruleId,
      Description: raw.Description || raw.desc || ruleId,
      File: file,
      StartLine: line,
      EndLine: raw.EndLine || line,
      Secret: (raw.Secret || match).slice(0, 80),
      Match: match,
      Entropy: raw.Entropy || raw.entropy || 0,
      severity,
      secret_type: secretType,
      detector: raw.detector || raw.engine || 'Admin Scanner',
      confidence: raw.confidence ?? (severity === 'CRITICAL' ? 85 : severity === 'HIGH' ? 70 : 50),
      privilege: raw.privilege || inferPrivilege(secretType, severity),
      status: raw.status || 'Active',
      exposure_days: raw.exposure_days ?? 0,
      repo: raw.repo || ctx.repoName,
      repo_visibility: raw.repo_visibility || ctx.visibility || 'Unknown',
      scannedAt: raw.scannedAt || ctx.scannedAt,
      inComment: raw.inComment || false,
      Link: raw.Link || raw.link || `${ctx.repoUrl}/blob/HEAD/${file}#L${line}`,
    };
  }

  const file = raw.file || '';
  const ruleId = raw.rule || raw.ruleId || 'unknown';
  const match = raw.value || raw.match || '';
  const severity = (raw.severity || 'HIGH').toUpperCase();
  const line = raw.line || 1;
  const secretType = inferSecretType(ruleId, raw.desc);
  return {
    id: raw.id || generateFindingId({ File: file, RuleID: ruleId, StartLine: line, Match: match }),
    RuleID: ruleId,
    Description: raw.desc || ruleId,
    File: file,
    StartLine: line,
    EndLine: line,
    Secret: match.slice(0, 80),
    Match: match,
    Entropy: raw.entropy || 0,
    severity,
    secret_type: secretType,
    detector: raw.engine || 'Admin Scanner',
    confidence: severity === 'CRITICAL' ? 85 : severity === 'HIGH' ? 70 : 50,
    privilege: inferPrivilege(secretType, severity),
    status: 'Active',
    exposure_days: 0,
    repo: ctx.repoName,
    repo_visibility: ctx.visibility || 'Unknown',
    scannedAt: ctx.scannedAt,
    inComment: false,
    Link: `${ctx.repoUrl}/blob/HEAD/${file}#L${line}`,
  };
}

function normalizeAdminFindings(rawFindings, ctx) {
  if (!Array.isArray(rawFindings)) return [];
  return rawFindings.map(f => normalizeAdminFinding(f, ctx));
}
// â”€â”€â”€ CORS â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());

// â”€â”€â”€ Serve static assets (CSS, JS, images, font files etc.) â”€â”€â”€â”€â”€â”€â”€
app.use(express.static(ROOT));

// â”€â”€â”€ HTML page routes â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
app.get('/',                    (req, res) => sendHtml(res, 'index.html'));
app.get('/index.html',          (req, res) => sendHtml(res, 'index.html'));
app.get('/dashboard-admin.html',(req, res) => sendHtml(res, 'dashboard-admin.html'));
app.get('/dashboard-user.html', (req, res) => sendHtml(res, 'dashboard-user.html'));

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// USERS â€” edit passwords here or set env vars ADMIN_PASS / USER_PASS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
const USERS = {
  admin: { password: process.env.ADMIN_PASS || 'admin123', role: 'admin' },
  user:  { password: process.env.USER_PASS  || 'user123',  role: 'user'  },
};

// In-memory token store
const TOKENS      = new Map();
const TOKEN_TTL   = 8 * 60 * 60 * 1000; // 8 hours

function makeToken()    { return crypto.randomBytes(32).toString('hex'); }
function cleanTokens()  {
  const now = Date.now();
  for (const [t, d] of TOKENS) if (d.expires < now) TOKENS.delete(t);
}

// â”€â”€â”€ Auth middleware â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function requireAuth(req, res, next) {
  const auth  = req.headers['authorization'] || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : (req.query && req.query.token) || null;
  if (!token) return res.status(401).json({ error: 'Not signed in' });
  cleanTokens();
  const sess = TOKENS.get(token);
  if (!sess || sess.expires < Date.now()) {
    TOKENS.delete(token);
    return res.status(401).json({ error: 'Session expired â€” sign in again' });
  }
  req.user = sess.username;
  req.role = sess.role;
  next();
}

function requireAdmin(req, res, next) {
  if (req.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
  next();
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// AUTH ENDPOINTS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

// POST /api/auth/login
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password)
    return res.status(400).json({ error: 'Username and password required' });
  const user = USERS[username];
  if (!user || user.password !== password)
    return res.status(401).json({ error: 'Invalid username or password' });
  const token = makeToken();
  TOKENS.set(token, { username, role: user.role, expires: Date.now() + TOKEN_TTL });
  console.log(`[auth] ${username} (${user.role}) signed in`);
  res.json({ token, role: user.role, username });
});

// POST /api/auth/logout
app.post('/api/auth/logout', requireAuth, (req, res) => {
  const token = (req.headers['authorization'] || '').slice(7);
  TOKENS.delete(token);
  console.log(`[auth] ${req.user} signed out`);
  res.json({ ok: true });
});

// GET /api/auth/me
app.get('/api/auth/me', requireAuth, (req, res) => {
  res.json({ username: req.user, role: req.role });
});

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// FINDINGS â€” all authenticated users
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

app.get('/api/results', (req, res) => {
  try {
    res.json({ findings: readLatestFindings() });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/scored', requireAuth, (req, res) => {
  try {
    res.json({ scored: normalizeFindings(readJsonFile('scored-results.json', [])) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/servicenow/list', requireAuth, (req, res) => {
  try {
    const snf = path.join(ROOT, 'servicenow_incidents.json');
    const sf  = path.join(ROOT, 'scored-results.json');
    const ff  = path.join(ROOT, 'findings.json');
    const f   = fs.existsSync(snf) ? snf
              : fs.existsSync(sf)  ? sf
              : fs.existsSync(ff)  ? ff
              : null;
    if (!f) return res.json({ findings: [] });
    const d = JSON.parse(fs.readFileSync(f, 'utf8'));
    res.json({ findings: d.findings || d.scored || [] });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// SSE progress stream
const clients = new Set();
app.get('/api/scan/progress', requireAuth, (req, res) => {
  res.setHeader('Content-Type',  'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection',    'keep-alive');
  clients.add(res);
  req.on('close', () => clients.delete(res));
});
function broadcast(obj) {
  const msg = `data: ${JSON.stringify(obj)}\n\n`;
  for (const c of clients) { try { c.write(msg); } catch {} }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// REPOS â€” aggregated repository data (authenticated users)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function exRepo(link) { try { return link.split('/')[4] || ''; } catch { return ''; } }

function inferRepoLanguage(findingDetails) {
  const langs = new Set();
  for (const f of findingDetails || []) {
    const file = (f.file || '').toLowerCase();
    if (file.endsWith('.php')) langs.add('PHP');
    else if (file.endsWith('.py')) langs.add('Python');
    else if (file.endsWith('.js') || file.endsWith('.ts') || file.endsWith('.jsx') || file.endsWith('.tsx')) langs.add('JavaScript');
    else if (file.endsWith('.go')) langs.add('Go');
    else if (file.endsWith('.java')) langs.add('Java');
    else if (file.endsWith('.rb')) langs.add('Ruby');
    else if (file.endsWith('.tf') || file.endsWith('.hcl')) langs.add('HCL');
    else if (file.endsWith('.yml') || file.endsWith('.yaml')) langs.add('YAML');
    else if (file.endsWith('.sh')) langs.add('Shell');
  }
  if (!langs.size) return '—';
  return [...langs].slice(0, 3).join(' / ');
}

function readRepoMeta() {
  try {
    const f = path.join(ROOT, 'repo-meta.json');
    if (!fs.existsSync(f)) return {};
    return JSON.parse(fs.readFileSync(f, 'utf8')).repos || {};
  } catch { return {}; }
}

function formatDuration(ms) {
  if (!ms || ms <= 0) return '—';
  const sec = Math.round(ms / 1000);
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  const rem = sec % 60;
  return `${min}m ${rem}s`;
}

function formatSizeKb(kb) {
  if (!kb && kb !== 0) return '—';
  if (kb < 1024) return `${kb} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
}

function formatDisplayDate(iso) {
  if (!iso || iso === '—') return '—';
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return String(iso).slice(0, 16).replace('T', ' ');
    return d.toISOString().slice(0, 16).replace('T', ' ');
  } catch { return String(iso); }
}

function relativeAgo(iso) {
  if (!iso || iso === '—') return '';
  try {
    const diff = Date.now() - new Date(iso).getTime();
    if (diff < 0) return 'just now';
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins || 1}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 48) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
  } catch { return ''; }
}

async function fetchGitHubRepoMeta(owner, repo) {
  const token = process.env.GITHUB_TOKEN || '';
  const headers = {
    Accept: 'application/vnd.github+json',
    'User-Agent': 'SecretSentinel/1.0',
  };
  if (token) headers.Authorization = `Bearer ${token}`;
  try {
    const res = await fetch(`https://api.github.com/repos/${owner}/${repo}`, { headers });
    if (!res.ok) return null;
    const data = await res.json();
    let openPRs = 0;
    try {
      const prRes = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/pulls?state=open&per_page=100`,
        { headers }
      );
      if (prRes.ok) {
        const pulls = await prRes.json();
        openPRs = Array.isArray(pulls) ? pulls.length : 0;
      }
    } catch {}
    return {
      language: data.language || null,
      size: formatSizeKb(data.size),
      lastCommit: formatDisplayDate(data.pushed_at),
      openPRs,
      defaultBranch: data.default_branch || 'main',
      description: data.description || '',
    };
  } catch { return null; }
}

app.get('/api/repos', async (req, res) => {
  try {
    const findings = readLatestFindings();
    const repoMeta = readRepoMeta();
    const repoMap = {};
    findings.forEach(f => {
      const name = f.repo || exRepo(f.Link || f.link || '') || 'Unknown';
      if (!repoMap[name]) repoMap[name] = { name, findings: 0, critical: 0, high: 0, medium: 0, low: 0, scores: [], vis: f.repo_visibility || 'Unknown', dates: [], findingDetails: [], commitDates: [] };
      repoMap[name].findings++;
      repoMap[name].scores.push(f.risk_score || f.riskScore || 0);
      repoMap[name].dates.push(f.Date || f.date || f.scannedAt || '');
      repoMap[name].commitDates.push(f.commitDate || f.Date || '');
      const sev = f.severity || f.sev || 'HIGH';
      if (sev === 'CRITICAL') repoMap[name].critical++;
      else if (sev === 'HIGH') repoMap[name].high++;
      else if (sev === 'MEDIUM') repoMap[name].medium++;
      else repoMap[name].low++;
      repoMap[name].findingDetails.push({
        id: f.id || f.idx || (repoMap[name].findings),
        secretType: f.secret_type || f.secretType || '',
        file: f.File || f.file || '',
        line: f.StartLine || f.line || 0,
        sev,
        riskScore: f.risk_score || f.riskScore || 0,
        status: f.status || 'Active',
        link: f.Link || f.link || '',
      });
    });

    const repos = Object.values(repoMap);
    for (const r of repos) {
      r.avgScore = r.scores.length ? Math.round(r.scores.reduce((a, b) => a + b, 0) / r.scores.length) : 0;
      r.status = r.critical ? 'CRITICAL' : r.high ? 'HIGH' : r.medium ? 'MEDIUM' : 'CLEAN';
      r.latestDate = r.dates.filter(Boolean).sort().pop() || '—';
      r.findingsList = r.findingDetails;

      const meta = repoMeta[r.name] || {};
      const firstLink = r.findingDetails.find(f => f.link)?.link || '';
      const urlMatch = firstLink.match(/(https:\/\/github\.com\/[^/]+\/[^/]+)/i);
      r.url = meta.url || (urlMatch ? urlMatch[1] : `https://github.com/${r.name}`);
      r.org = meta.org || (r.url.match(/github\.com\/([^/]+)/i) || [])[1] || 'unknown';
      r.vis = meta.visibility || r.vis || 'Unknown';

      const uniqueFiles = new Set(r.findingDetails.map(f => f.file).filter(Boolean));
      r.scannedFiles = meta.scannedFiles || uniqueFiles.size;
      r.language = inferRepoLanguage(r.findingDetails);
      r.lastCommit = formatDisplayDate(
        (r.commitDates.filter(Boolean).sort().pop()) || meta.scannedAt || r.latestDate
      );
      r.riskScore = r.avgScore;
      r.scanDuration = formatDuration(meta.durationMs);
      r.schedule = meta.schedule || 'Manual';
      r.lastScan = formatDisplayDate(meta.scannedAt || r.latestDate);
      r.lastScanAgo = relativeAgo(meta.scannedAt || r.latestDate);
      r.nextScan = '—';
      r.nextScanIn = '—';
      r.depth = meta.depth || 50;
      r.allBranches = false;
      r.token = process.env.GITHUB_TOKEN ? 'ghp_••••' + (process.env.GITHUB_TOKEN.slice(-4) || '') : 'Not configured';
      r.tokenExpiry = '—';
      r.defaultBranch = meta.defaultBranch || 'main';
      r.openPRs = '—';
      r.size = '—';
      r.description = meta.description || (r.findings
        ? `${r.name} — ${r.findings} secret finding(s) detected across ${uniqueFiles.size} file(s).`
        : `${r.name} — no secrets detected in the latest scan.`);
      r.scanHistory = (meta.scanHistory || []).map(h => ({
        date: formatDisplayDate(h.date),
        duration: formatDuration(h.durationMs),
        findings: h.findings,
        status: h.status,
        files: h.files,
      }));
      if (!r.scanHistory.length) {
        r.scanHistory = [{
          date: r.lastScan,
          duration: r.scanDuration,
          findings: r.findings,
          status: r.status,
          files: r.scannedFiles,
        }];
      }
      r.trend = r.scanHistory.slice(0, 7).reverse().map(h => h.findings);
      if (r.trend.length < 7) {
        while (r.trend.length < 7) r.trend.unshift(0);
      }
      r.trendColor = r.status === 'CRITICAL' ? 'var(--cr)' : r.status === 'HIGH' ? 'var(--hi)' : r.status === 'MEDIUM' ? 'var(--me)' : 'var(--lo)';

      const gh = await fetchGitHubRepoMeta(r.org, r.name);
      if (gh) {
        if (gh.language) r.language = gh.language;
        if (gh.size) r.size = gh.size;
        if (gh.lastCommit && gh.lastCommit !== '—') r.lastCommit = gh.lastCommit;
        if (gh.openPRs !== undefined) r.openPRs = gh.openPRs;
        if (gh.defaultBranch) r.defaultBranch = gh.defaultBranch;
        if (gh.description) r.description = gh.description;
      }
    }
    repos.sort((a, b) => b.avgScore - a.avgScore);
    res.json({ repos, lastScanAgo: repos.length ? relativeAgo(repos[0]?.lastScan) : '' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// ADMIN DASHBOARD BACKEND ROUTES
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

// POST /api/fetch-files — proxy for GitHub file fetching (used by admin dashboard scan engine)
app.post('/api/fetch-files', requireAuth, requireAdmin, async (req, res) => {
  const { repoUrl, token, exclusions } = req.body;
  if (!repoUrl) return res.status(400).json({ error: 'No repoUrl provided' });
  try {
    const match = repoUrl.replace(/\.git$/, '').match(/github\.com\/([^/]+)\/([^/]+)/);
    if (!match) return res.status(400).json({ error: 'Invalid GitHub URL' });
    const [, owner, repo] = match;
    const headers = { Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' };
    if (token) headers.Authorization = 'Bearer ' + token;
    const repoInfo = await fetch(`https://api.github.com/repos/${owner}/${repo}`, { headers }).then(r => r.json());
    if (repoInfo.message) return res.status(400).json({ error: 'GitHub API: ' + repoInfo.message });
    const branch = repoInfo.default_branch || 'main';
    const treeRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/trees/${branch}?recursive=1`, { headers });
    const tree = await treeRes.json();
    if (!tree.tree) return res.status(400).json({ error: tree.message || 'Cannot read tree' });
    const extList = (exclusions?.extensions || []).map(e => e.replace(/\./g, '\\.')).join('|');
    const extRe = extList ? new RegExp('(?:' + extList + ')$', 'i') : null;
    const textFiles = tree.tree.filter(f => f.type === 'blob' && f.size < 300000 && (!extRe || !extRe.test(f.path)));
    const toFetch = textFiles.slice(0, 80);
    const results = [];
    for (let i = 0; i < toFetch.length; i += 10) {
      const batch = toFetch.slice(i, i + 10);
      const settled = await Promise.allSettled(
        batch.map(f =>
          fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(f.path)}`, { headers })
            .then(r => r.json())
            .then(d => ({ path: f.path, content: d.encoding === 'base64' ? atob(d.content.replace(/\n/g, '')) : '' }))
        )
      );
      settled.forEach(r => { if (r.status === 'fulfilled' && r.value.content) results.push(r.value); });
    }
    res.json({ files: results });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/scan-results — store scan results from admin dashboard
app.post('/api/scan-results', requireAuth, requireAdmin, (req, res) => {
  try {
    const data = req.body;
    if (!data) return res.status(400).json({ error: 'No data' });

    const repoUrl = (data.repoUrl || '').replace(/\.git$/, '').replace(/\/$/, '');
    const repoName = repoUrl
      ? repoUrl.split('/').filter(Boolean).slice(-1)[0]
      : 'unknown';
    const scannedAt = data.scannedAt || new Date().toISOString();
    const ctx = {
      repoUrl,
      repoName,
      scannedAt,
      visibility: data.visibility || 'Unknown',
    };

    const findings = normalizeAdminFindings(data.findings || [], ctx);

    // Accumulate: keep findings from other repos, replace findings for this repo
    const accumulated = normalizeFindings(readJsonFile('findings.json', { findings: [] }))
      .filter(f => f.repo !== repoName);
    const allFindings = [...accumulated, ...findings];

    fs.writeFileSync(path.join(ROOT, 'scan-results.json'), JSON.stringify(allFindings, null, 2));
    saveFindings(allFindings);
    try { fs.unlinkSync(path.join(ROOT, 'scored-results.json')); } catch {}

    const metaPath = path.join(ROOT, 'repo-meta.json');
    let meta = {};
    try { meta = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch {}
    meta.repos = meta.repos || {};
    meta.repos[repoName] = {
      url: repoUrl,
      org: repoUrl.match(/github\.com\/([^/]+)/i)?.[1] || 'unknown',
      visibility: ctx.visibility,
      scannedAt,
      scannedFiles: data.fileCount || 0,
      findings: findings.length,
      engines: data.engines || [],
      durationMs: data.durationMs || 0,
      schedule: 'Manual',
      scanHistory: [
        ...(meta.repos[repoName]?.scanHistory || []),
        {
          date: scannedAt,
          findings: findings.length,
          status: findings.some(f => f.severity === 'CRITICAL') ? 'CRITICAL'
            : findings.some(f => f.severity === 'HIGH') ? 'HIGH'
            : findings.length ? 'MEDIUM' : 'CLEAN',
          files: data.fileCount || 0,
        },
      ].slice(0, 10),
    };
    fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2));

    console.log(`[scan-results] Saved ${findings.length} findings for ${repoName} (${allFindings.length} total across all repos)`);
    res.json({ ok: true, total: findings.length });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/config — save full configuration (exclusions, toggles, custom rules)
app.post('/api/config', requireAuth, requireAdmin, (req, res) => {
  try {
    const config = req.body;
    if (!config) return res.status(400).json({ error: 'No config data' });
    fs.writeFileSync(path.join(ROOT, 'admin-config.json'), JSON.stringify(config, null, 2));
    // Save custom rules to a SEPARATE file so we never clobber the real patterns.js
    if (config.customRules) {
      fs.writeFileSync(path.join(ROOT, 'admin-custom-rules.json'),
        JSON.stringify({ customRegexRules: config.customRules }, null, 2)
      );
    }
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/exclusions — save exclusion rules
app.post('/api/exclusions', requireAuth, requireAdmin, (req, res) => {
  try {
    const exclusions = req.body;
    if (!exclusions) return res.status(400).json({ error: 'No exclusions data' });
    fs.writeFileSync(path.join(ROOT, 'exclusions.json'), JSON.stringify(exclusions, null, 2));
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/config/risk-rules — load risk calculation rules
app.get('/api/config/risk-rules', requireAuth, requireAdmin, (req, res) => {
  try {
    const f = path.join(ROOT, 'risk-rules.json');
    if (fs.existsSync(f)) {
      res.json(JSON.parse(fs.readFileSync(f, 'utf8')));
    } else {
      // Return defaults
      res.json({
        sevCritical: '36', sevHigh: '25', sevMedium: '15', sevLow: '5',
        privAdmin: '30', privHigh: '25', privMedium: '15', privLow: '5',
        expDaysFactor: '0.6', expDaysCap: '30', expPublicBonus: '10', expMaxBatch: '10',
        threshCritical: '85', threshHigh: '65', threshMedium: '40',
        repoHealthCriticalWeight: '5', repoHealthHighWeight: '2', repoHealthMediumWeight: '1', repoHealthLowWeight: '0.5'
      });
    }
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/config/risk-rules — save risk calculation rules
app.post('/api/config/risk-rules', requireAuth, requireAdmin, (req, res) => {
  try {
    const rules = req.body;
    if (!rules) return res.status(400).json({ error: 'No rules data' });
    fs.writeFileSync(path.join(ROOT, 'risk-rules.json'), JSON.stringify(rules, null, 2));
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/config/findings — save finding creation rules
app.post('/api/config/findings', requireAuth, requireAdmin, (req, res) => {
  try {
    const rules = req.body;
    if (!rules) return res.status(400).json({ error: 'No rules data' });
    fs.writeFileSync(path.join(ROOT, 'finding-rules.json'), JSON.stringify(rules, null, 2));
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// ADMIN-ONLY ENDPOINTS (original)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

// POST /api/scan
app.post('/api/scan', requireAuth, requireAdmin,async (req, res) => {
  const { urls, token: ghToken } = req.body;
  if (!urls || !urls.length)
    return res.status(400).json({ error: 'No URLs provided' });

  broadcast({ log: `=== Scanning ${urls.length} repo(s) ===` });
  // Clear per-scan result files; keep findings.json so multi-repo findings accumulate
  for (const f of ['scan-results.json', 'scored-results.json']) {
    try { fs.unlinkSync(path.join(ROOT, f)); } catch {}
  }
  // Pre-remove the repo(s) being re-scanned from accumulated findings to avoid stale data
  const scanRepoNames = urls.map(u => u.replace(/\.git$/, '').split('/').filter(Boolean).pop() || '');
  try {
    const existingFindings = normalizeFindings(readJsonFile('findings.json', { findings: [] }));
    const filtered = existingFindings.filter(f => !scanRepoNames.includes(f.repo));
    if (filtered.length !== existingFindings.length) saveFindings(filtered);
  } catch {}
  const env = { ...process.env };
  if (ghToken) env.GITHUB_TOKEN = ghToken;

  const proc = spawn('node', ['test-scan.js', ...urls], { cwd: ROOT, env });
  let procOutput = '';
  proc.stdout.on('data', d => {
    const text = d.toString().trim();
    broadcast({ log: text });
    procOutput += text + '\n';
  });
  proc.stderr.on('data', d => {
    const text = d.toString().trim();
    broadcast({ log: `[stderr] ${text}` });
    procOutput += '[stderr] ' + text + '\n';
  });
  proc.on('close',async code => {
    broadcast({ log: code === 0 ? 'Scan complete' : `[Error] code ${code} — all repos failed to scan, no data was overwritten`, done: true });
    if (code !== 0) {
      const lastLines = procOutput.split('\n').filter(l => l.trim()).slice(-20).join('\n');
      return res.status(500).json({
        error: `Scan failed for all provided URL(s).`,
        details: lastLines || 'No output captured. Check that the URL is a valid GitHub repository and accessible.'
      });
    }
    try {
      // Merge new scan findings with accumulated findings from other repos
      const newFindings = normalizeFindings(readJsonFile('scan-results.json', []));
      const accumulated = normalizeFindings(readJsonFile('findings.json', { findings: [] }));
      const allFindings = [...accumulated, ...newFindings];
      // Update both files so the dashboard sees all repos' findings
      fs.writeFileSync(path.join(ROOT, 'scan-results.json'), JSON.stringify(allFindings, null, 2));
      saveFindings(allFindings);

      const repoUrl = urls[0];
      const repoName = repoUrl.replace(/\.git$/, '').split('/').filter(Boolean).pop() || 'unknown';

      if (supabase) {
        const scanRow = {
          repo_url: repoUrl,
          repo_name: repoName,
          visibility: newFindings[0]?.repo_visibility || 'Unknown',
          total_findings: newFindings.length
        };

        const { data: scan, error: scanError } = await supabase
          .from('scans')
          .insert(scanRow)
          .select()
          .single();

        if (scanError) {
          console.error('[supabase] scan insert error:', scanError.message);
        } else {
          const findingRows = newFindings.map(f => ({
            scan_id:         scan.id,
            finding_id:      f.id,
            rule_id:         f.RuleID,
            description:     f.Description,
            file:            f.File,
            start_line:      f.StartLine,
            secret:          f.Secret,
            match:           f.Match,
            entropy:         f.Entropy,
            commit:          f.Commit,
            author:          f.Author,
            email:           f.Email,
            date:            f.scannedAt,
            fingerprint:     f.Fingerprint,
            secret_type:     f.secret_type,
            severity:        f.severity,
            confidence:      f.confidence,
            detector:        f.detector,
            repo:            repoName,
            repo_visibility: f.repo_visibility
          }));

          if (findingRows.length) {
            const { error: findingError } = await supabase
              .from('findings')
              .upsert(findingRows, { onConflict: 'finding_id', ignoreDuplicates: false });
            if (findingError) console.error('[supabase] findings upsert error:', findingError.message);
          }
        }
      }

      res.json({ findings: allFindings, total: allFindings.length, errors: [] });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });
});
// POST /api/score
app.post('/api/score', requireAuth, async (req, res) => {
  try {
    let findings = normalizeFindings(req.body?.findings);
    if (!findings.length) findings = readLatestFindings();
    if (!findings.length) return res.status(400).json({ error: 'No findings to score' });
    saveFindings(findings);
    const scored = scoreFindings(findings);

    if (supabase) {
      const scoreRows = scored.map(f => ({
        finding_id:       f.id,
        rule_score:       f.rule_score,
        ai_score:         f.ai_score,
        risk_score:       f.risk_score,
        risk_level:       f.risk_level,
        ai_justification: f.ai_justification
      }));
      const { error: scoreError } = await supabase
        .from('scored_findings')
        .upsert(scoreRows, { onConflict: 'finding_id', ignoreDuplicates: false });
      if (scoreError) console.error('[supabase] scored_findings upsert error:', scoreError.message);
    }

    fs.writeFileSync(path.join(ROOT, 'scored-results.json'), JSON.stringify({ scored }, null, 2));
    broadcast({ log: `Scored ${scored.length} findings`, done: true });
    res.json({ scored });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
// POST /api/report
app.post('/api/report', requireAuth, requireAdmin, (req, res) => {
  const proc = spawn('node', ['reporter.js'], { cwd: ROOT });
  let report = '';
  proc.stdout.on('data', d => { report += d; });
  proc.on('close',async code => {
    if (code !== 0) return res.status(500).json({ error: 'Reporter failed' });
    res.json({ report, lines: report.split('\n').length });
  });
});

// GET /api/servicenow/config
app.get('/api/servicenow/config', requireAuth, requireAdmin, (req, res) => {
  try {
    const f   = path.join(ROOT, 'config.json');
    const cfg = fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : {};
    res.json({ configured: !!(cfg.instanceUrl && cfg.username), instanceUrl: cfg.instanceUrl || '', username: cfg.username || '' });
  } catch { res.json({ configured: false }); }
});

// POST /api/servicenow/config
app.post('/api/servicenow/config', requireAuth, requireAdmin, async(req, res) => {
  const { instanceUrl, username, password } = req.body;
  if (!instanceUrl || !username || !password)
    return res.status(400).json({ error: 'All three fields required' });
  fs.writeFileSync(path.join(ROOT, 'config.json'), JSON.stringify({ instanceUrl, username, password }, null, 2));
  console.log('[sn] config.json saved');
  res.json({ ok: true });
});

// POST /api/servicenow/test — actually validate credentials against the ServiceNow instance
app.post('/api/servicenow/test', requireAuth, requireAdmin, async (req, res) => {
  const { instanceUrl, username, password } = req.body || {};
  if (!instanceUrl || !username || !password)
    return res.status(400).json({ error: 'All fields required' });
  try {
    const url  = instanceUrl.replace(/\/$/, '') + '/api/now/table/incident?sysparm_limit=1&sysparm_fields=number';
    const auth = Buffer.from(`${username}:${password}`).toString('base64');
    const r    = await fetch(url, {
      headers: { Authorization: `Basic ${auth}`, Accept: 'application/json' },
      signal: AbortSignal.timeout(8000),
    });
    if (r.ok)           return res.json({ ok: true });
    if (r.status === 401) return res.status(401).json({ error: 'Invalid username or password' });
    return res.status(r.status).json({ error: `ServiceNow returned HTTP ${r.status}` });
  } catch (e) {
    const msg = e.name === 'TimeoutError' ? 'Connection timed out' : 'Cannot reach ServiceNow: ' + e.message;
    return res.status(500).json({ error: msg });
  }
});

// POST /api/fcr/execute — apply FCR rules to current findings, optionally create SN incidents
app.post('/api/fcr/execute', requireAuth, requireAdmin, async (req, res) => {
  try {
    const { rules, createSnIncidents } = req.body || {};
    const findings = readLatestFindings();
    if (!findings.length) return res.status(400).json({ error: 'No findings available. Run a scan first.' });

    const fcr        = rules || {};
    const minSev     = fcr.minSeverity || 'HIGH';
    const minRisk    = +(fcr.minRisk || 0);
    const types      = Array.isArray(fcr.secretTypes) ? fcr.secretTypes : [];
    const sevOrder   = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };

    const filtered = findings.filter(f => {
      const sev = (f.severity || 'HIGH').toUpperCase();
      if ((sevOrder[sev] ?? 3) > (sevOrder[minSev] ?? 3)) return false;
      if (minRisk > 0 && (f.risk_score || f.riskScore || 0) < minRisk) return false;
      if (types.length > 0) {
        const engine = (f.detector || f.engine || '').toLowerCase();
        const rule   = (f.RuleID   || f.rule   || '').toLowerCase();
        const desc   = (f.Description || f.desc || f.secret_type || '').toLowerCase();
        const match  = types.some(id => {
          if (id === 'api_key')     return engine.includes('gitleaks') || rule.includes('api') || desc.includes('api key');
          if (id === 'password')    return rule.includes('password') || desc.includes('password');
          if (id === 'db_conn')     return desc.includes('database') || desc.includes('connection') || rule.includes('db');
          if (id === 'cloud_key')   return desc.includes('aws') || desc.includes('gcp') || desc.includes('azure') || rule.includes('aws');
          if (id === 'token')       return desc.includes('token') || desc.includes('jwt') || desc.includes('oauth') || desc.includes('bearer');
          if (id === 'private_key') return desc.includes('private key') || desc.includes('rsa') || desc.includes('ssh');
          if (id === 'webhook')     return desc.includes('webhook') || rule.includes('webhook');
          if (id === 'cert')        return desc.includes('certif') || rule.includes('cert');
          if (id === 'stripe')      return desc.includes('stripe') || rule.includes('stripe') || desc.includes('payment');
          if (id === 'other')       return true;
          return false;
        });
        if (!match) return false;
      }
      return true;
    });

    let snCreated = 0;
    const snErrors = [];

    if (createSnIncidents) {
      const cfgPath = path.join(ROOT, 'config.json');
      if (!fs.existsSync(cfgPath))
        return res.status(400).json({ error: 'ServiceNow not configured. Save config in the ServiceNow tab first.' });
      const snCfg  = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      const base   = (snCfg.instanceUrl || '').replace(/\/$/, '');
      const auth   = Buffer.from(`${snCfg.username}:${snCfg.password}`).toString('base64');

      for (const f of filtered) {
        try {
          const sev = (f.severity || 'HIGH').toUpperCase();
          const r = await fetch(`${base}/api/now/table/incident`, {
            method:  'POST',
            headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' },
            body: JSON.stringify({
              short_description: `[SecretSentinel] ${sev} Secret: ${f.secret_type || f.RuleID || f.rule || 'Unknown'} in ${f.repo || 'Unknown'}`,
              description: `Repo: ${f.repo || 'Unknown'}\nFile: ${f.File || f.file || 'N/A'}\nLine: ${f.StartLine || f.line || 'N/A'}\nRule: ${f.RuleID || f.rule || 'Unknown'}\nSeverity: ${sev}\nFingerprint: ${f.Fingerprint || f.id || 'N/A'}`,
              urgency: sev === 'CRITICAL' ? '1' : sev === 'HIGH' ? '2' : '3',
              impact:  sev === 'CRITICAL' ? '1' : sev === 'HIGH' ? '2' : '3',
              category: 'Security',
            }),
            signal: AbortSignal.timeout(10000),
          });
          if (r.ok) snCreated++;
          else snErrors.push(`${f.id}: HTTP ${r.status}`);
        } catch (e) {
          snErrors.push(`${f.id}: ${e.message}`);
        }
      }
    }

    res.json({ total: findings.length, created: filtered.length, skipped: findings.length - filtered.length, snCreated, snErrors: snErrors.slice(0, 5) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/servicenow/create
// POST /api/servicenow/create
app.post('/api/servicenow/create', requireAuth, requireAdmin, async (req, res) => {
  broadcast({ log: '[ServiceNow] Running app.py...' });

  const proc = spawn('python', ['app.py'], { cwd: ROOT });

  proc.stdout.on('data', d =>
    broadcast({ log: d.toString().trim() })
  );

  proc.stderr.on('data', d =>
    broadcast({ log: `[stderr] ${d.toString().trim()}` })
  );

  let stderrOutput = '';

proc.stderr.on('data', d => {
  stderrOutput += d.toString();
  console.error('PYTHON ERROR:', d.toString());
});

proc.on('close', async code => {
  broadcast({ done: true });

  if (code !== 0) {
    return res.status(500).json({ error: 'app.py failed', details: stderrOutput });
  }

  try {
    const d = JSON.parse(
      fs.readFileSync(path.join(ROOT, 'servicenow_incidents.json'), 'utf8')
    );

    const inc = (d.findings || []).filter(f => f.incidentNum);

    const incidentRows = inc.map(f => ({
      finding_id: f.id,
      incident_number: f.incidentNum,
      sn_link: f.snLink
    }));

    console.log("Incidents to insert:", incidentRows);
    const { data, error } = await supabase
      .from('incidents')
      .insert(incidentRows)
      .select();
    console.log("Supabase result:", data, error);

    res.json({
      total: inc.length,
      incidentNums: inc.map(f => f.incidentNum)
    });

  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});
});

// POST /api/servicenow/ensure-incidents
// Generates mock SN incident numbers for all findings that don't yet have one.
// Uses the same severity-threshold logic as the FCR rules (default: HIGH+CRITICAL).
// Safe to call repeatedly — skips findings that already have an incidentNum.
app.post('/api/servicenow/ensure-incidents', requireAuth, async (req, res) => {
  try {
    const findings = readLatestFindings();
    if (!findings.length) return res.status(400).json({ error: 'No findings available. Run a scan first.' });

    const snfPath = path.join(ROOT, 'servicenow_incidents.json');
    // Load existing incidentNum mapping keyed by finding id
    const existing = {};
    if (fs.existsSync(snfPath)) {
      try {
        const d = JSON.parse(fs.readFileSync(snfPath, 'utf8'));
        const arr = d.findings || d.scored || (Array.isArray(d) ? d : []);
        arr.forEach(f => { if (f.id && f.incidentNum) existing[f.id] = { incidentNum: f.incidentNum, snLink: f.snLink || '' }; });
      } catch {}
    }

    // Severity threshold from request body (default: create for ALL findings)
    const minSev = (req.body?.minSeverity || 'LOW').toUpperCase();
    const sevOrder = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };

    // Sequential counter starting after any already-assigned incidents
    let counter = Object.keys(existing).length + 1;
    const cfgPath = path.join(ROOT, 'config.json');
    const snCfg = fs.existsSync(cfgPath) ? JSON.parse(fs.readFileSync(cfgPath, 'utf8')) : {};
    const base = (snCfg.instanceUrl || '').replace(/\/$/, '');

    const updated = findings.map(f => {
      const copy = { ...f };
      if (existing[f.id]) {
        // Already has an incident — preserve it
        copy.incidentNum = existing[f.id].incidentNum;
        copy.snLink      = existing[f.id].snLink;
      } else {
        const sev = (f.severity || f.sev || 'HIGH').toUpperCase();
        if ((sevOrder[sev] ?? 3) <= (sevOrder[minSev] ?? 3)) {
          const num = String(counter++).padStart(7, '0');
          copy.incidentNum = `INC${num}`;
          // Generate a realistic-looking SN deep-link (demo only)
          copy.snLink = base ? `${base}/nav_to.do?uri=incident.do?number=INC${num}` : '';
        }
      }
      return copy;
    });

    const incList = updated.filter(f => f.incidentNum).map(f => f.incidentNum);
    const output = {
      createdAt: new Date().toISOString(),
      incidentNums: incList,
      total: incList.length,
      findings: updated,
    };
    fs.writeFileSync(snfPath, JSON.stringify(output, null, 2));
    console.log(`[sn] ensure-incidents: ${incList.length} incidents assigned`);
    res.json({ total: incList.length, incidentNums: incList });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/config/ai
app.get('/api/config/ai', requireAuth, requireAdmin, (req, res) => {
  try {
    const f = path.join(ROOT, 'ai-config.json');
    res.json(fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : {});
  } catch { res.json({}); }
});

// POST /api/config/ai
app.post('/api/config/ai', requireAuth, requireAdmin, (req, res) => {
  try {
    fs.writeFileSync(path.join(ROOT, 'ai-config.json'), JSON.stringify(req.body, null, 2));
    console.log('[config] ai-config.json saved');
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// STARTUP - print direct local links in the terminal
function printServerLinks(alreadyRunning = false) {
  const baseUrl = `http://localhost:${PORT}`;

  console.log('\nSecretSentinel local server');
  console.log('--------------------------------');
  if (alreadyRunning) {
    console.log(`Port ${PORT} is already in use.`);
    console.log('Another server is already running, so use this link:');
  } else {
    console.log('Server started successfully.');
  }
  console.log('');
  console.log(`Login page      : ${baseUrl}/`);
  console.log(`Admin dashboard : ${baseUrl}/dashboard-admin.html`);
  console.log(`User dashboard  : ${baseUrl}/dashboard-user.html`);
  console.log('');
  console.log(`Admin login     : admin / ${USERS.admin.password}`);
  console.log(`User login      : user / ${USERS.user.password}`);
  console.log('');
  console.log('Open this link for dashboard:');
  console.log(`${baseUrl}/dashboard-admin.html`);

  if (alreadyRunning) {
    console.log('\nTo stop the old server, close the terminal where it is running or run:');
    console.log('netstat -ano | findstr :3000');
    console.log('taskkill /PID <PID> /F');
  } else {
    console.log('\nPress Ctrl+C to stop');
  }
  console.log('');
}

const server = app.listen(PORT, () => {
  printServerLinks(false);

  const required = ['index.html', 'dashboard-admin.html', 'dashboard-user.html'];
  console.log('File check:');
  required.forEach(f => {
    const exists = fs.existsSync(path.join(ROOT, f));
    console.log(`  ${exists ? 'OK' : 'MISSING'} ${f}`);
  });
  console.log('');
});

server.on('error', err => {
  if (err && err.code === 'EADDRINUSE') {
    printServerLinks(true);
    process.exit(0);
  }
  console.error(err);
  process.exit(1);
});


