/**
 * gitleaksRunner.js
 * Thin wrapper around the Gitleaks binary.
 * Runs Gitleaks with your custom TOML rules and returns normalized findings.
 */

'use strict';

const { execSync, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const GITLEAKS_CONFIG = path.resolve(__dirname, '../config/.gitleaks.toml');
const GITLEAKS_TIMEOUT = 60_000; // 60 seconds

/**
 * Check if Gitleaks binary is available
 * @returns {boolean}
 */
function isGitleaksAvailable() {
  try {
    execSync('gitleaks version', { stdio: 'pipe' });
    return true;
  } catch {
    return false;
  }
}

/**
 * Normalize a Gitleaks finding to SecretSentinel's common schema
 * @param {Object} raw — raw Gitleaks JSON finding
 * @returns {Object}
 */
function normalizeGitleaksFinding(raw) {
  return {
    ruleId: raw.RuleID || raw.ruleId || 'gitleaks-unknown',
    description: raw.Description || raw.description || 'Secret detected by Gitleaks',
    file: raw.File || raw.file || '',
    line: raw.StartLine || raw.line || 0,
    match: raw.Secret
      ? raw.Secret.substring(0, 6) + '...' + raw.Secret.substring(Math.max(0, raw.Secret.length - 6))
      : '***',
    rawMatch: raw.Secret || '',
    severity: mapGitleaksSeverity(raw.Tags || []),
    confidence: 85,
    detector: 'Gitleaks',
    commit: raw.Commit || null,
    author: raw.Author || null,
    date: raw.Date || null,
    tags: raw.Tags || [],
  };
}

/**
 * Map Gitleaks tags to severity
 * @param {string[]} tags
 * @returns {string}
 */
function mapGitleaksSeverity(tags) {
  const lower = tags.map(t => t.toLowerCase());
  if (lower.includes('critical')) return 'CRITICAL';
  if (lower.includes('high')) return 'HIGH';
  if (lower.includes('medium')) return 'MEDIUM';
  return 'HIGH'; // Gitleaks findings are HIGH by default
}

/**
 * Run Gitleaks on a directory or file path
 * @param {string} targetPath — local path to scan
 * @param {Object} options
 * @param {boolean} options.scanHistory — scan full git history
 * @returns {Array} normalized findings
 */
function runGitleaks(targetPath, options = {}) {
  if (!isGitleaksAvailable()) {
    console.warn('[Gitleaks] Binary not found — skipping Gitleaks layer. Install: brew install gitleaks');
    return [];
  }

  const reportPath = path.join(os.tmpdir(), `gitleaks-${Date.now()}.json`);

  try {
    const args = [
      'detect',
      '--source', targetPath,
      '--report-format', 'json',
      '--report-path', reportPath,
      '--exit-code', '0',  // don't exit non-zero on findings
      '--no-banner',
    ];

    // Add custom config if it exists
    if (fs.existsSync(GITLEAKS_CONFIG)) {
      args.push('--config', GITLEAKS_CONFIG);
    }

    // Scan git history if requested
    if (options.scanHistory) {
      args.push('--log-opts', '--all');
    }

    const result = spawnSync('gitleaks', args, {
      timeout: GITLEAKS_TIMEOUT,
      encoding: 'utf8',
    });

    if (result.error) {
      console.error('[Gitleaks] Execution error:', result.error.message);
      return [];
    }

    // Read findings from report file
    if (!fs.existsSync(reportPath)) return [];

    const raw = fs.readFileSync(reportPath, 'utf8').trim();
    if (!raw || raw === 'null' || raw === '[]') return [];

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];

    return parsed.map(normalizeGitleaksFinding);

  } catch (err) {
    console.error('[Gitleaks] Failed:', err.message);
    return [];
  } finally {
    // Cleanup temp report file
    try { fs.unlinkSync(reportPath); } catch {}
  }
}

module.exports = { runGitleaks, isGitleaksAvailable };
