/**
 * deduplicator.js
 * Merges findings from all detection layers into one clean, deduplicated list.
 *
 * Fingerprint strategy:
 *   SHA-256(ruleId + file + line + first20charsOfRawMatch)
 *
 * When two findings share a fingerprint, keep the one with:
 *   - Higher confidence
 *   - More specific detector (CustomRegex > Entropy > Fuzzy)
 *
 * Also handles near-duplicates: same file + line but different ruleId
 * (e.g. Gitleaks AND CustomRegex both fire on same line).
 */

'use strict';

const crypto = require('crypto');

// Detector priority — lower number = higher priority when deduplicating same finding
const DETECTOR_PRIORITY = {
  'Gitleaks': 1,
  'CustomRegexScanner': 2,
  'AhoCorasickKeywordScanner': 3,
  'Base64Decoder': 4,
  'EntropyAnalyzer': 5,
  'FuzzyMatcher': 6,
};

/**
 * Generate a fingerprint for a finding
 * @param {Object} finding
 * @returns {string} hex fingerprint
 */
function fingerprint(finding) {
  let value = (finding.Secret || finding.rawMatch || finding.match || '');
  // Strip assignment prefix: token = "value" -> value
  value = value.replace(/^[\w\s@._-]*[:=]\s*['"`]?/, '');
  // Strip surrounding quotes
  value = value.replace(/^['"`]|['"`]$/g, '').trim();
  // Take first 30 chars for fingerprint
  value = value.substring(0, 30);

  const key = [
    finding.File || finding.file || '',
    String(finding.StartLine || finding.line || 0),
    value,
  ].join('::');

  return crypto.createHash('sha256').update(key).digest('hex').substring(0, 16);
}

/**
 * Generate a "same location" key — same file + line
 * Used for near-duplicate detection
 * @param {Object} finding
 * @returns {string}
 */
function locationKey(finding) {
  return `${finding.File || finding.file}::${finding.StartLine || finding.line}`;
}

/**
 * Compare two findings to decide which is higher quality
 * @param {Object} a
 * @param {Object} b
 * @returns {Object} the better finding
 */
function keepBetter(a, b) {
  // Higher confidence wins
  if (a.confidence !== b.confidence) {
    return a.confidence > b.confidence ? a : b;
  }
  // Higher detector priority wins
  const pa = DETECTOR_PRIORITY[a.detector] || 99;
  const pb = DETECTOR_PRIORITY[b.detector] || 99;
  return pa <= pb ? a : b;
}

/**
 * Deduplicate findings from all layers
 * @param {Array} allFindings — merged array from all detectors
 * @returns {Array} deduplicated, sorted findings
 */
function deduplicate(allFindings) {
  // ── Pass 1: exact fingerprint dedup ────────────────────────────────────────
  const byFingerprint = new Map();

  for (const finding of allFindings) {
    const fp = fingerprint(finding);
    if (!byFingerprint.has(fp)) {
      byFingerprint.set(fp, { ...finding, fingerprint: fp, sources: [finding.detector] });
    } else {
      const existing = byFingerprint.get(fp);
      const better = keepBetter(existing, finding);
      byFingerprint.set(fp, {
        ...better,
        fingerprint: fp,
        // Track all detectors that found this secret
        sources: [...new Set([...existing.sources, finding.detector])],
      });
    }
  }

  const deduped = Array.from(byFingerprint.values());

  // ── Pass 2: same-line consolidation ────────────────────────────────────────
  // If 3+ detectors fire on the same line, boost confidence slightly
  const byLocation = new Map();
  for (const finding of deduped) {
    const lk = locationKey(finding);
    if (!byLocation.has(lk)) {
      byLocation.set(lk, []);
    }
    byLocation.get(lk).push(finding);
  }

  const consolidated = deduped.map(finding => {
    const lk = locationKey(finding);
    const sameLinefindings = byLocation.get(lk) || [];
    const detectorCount = new Set(sameLinefindings.map(f => f.detector)).size;

    if (detectorCount >= 2) {
      // Multiple detectors agree — boost confidence
      return {
        ...finding,
        confidence: Math.min(99, finding.confidence + detectorCount * 5),
        multiDetector: true,
        detectorCount,
      };
    }
    return finding;
  });

  // ── Sort: CRITICAL → HIGH → MEDIUM → LOW, then by confidence desc ──────────
  const SEVERITY_ORDER = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
  consolidated.sort((a, b) => {
    const sa = SEVERITY_ORDER[a.severity] ?? 4;
    const sb = SEVERITY_ORDER[b.severity] ?? 4;
    if (sa !== sb) return sa - sb;
    return (b.confidence || 0) - (a.confidence || 0);
  });

  return consolidated;
}

/**
 * Generate a summary report of findings
 * @param {Array} findings — deduplicated findings
 * @returns {Object} summary
 */
function summarize(findings) {
  const bySeverity = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
  const byDetector = {};
  const byFile = {};

  for (const f of findings) {
    bySeverity[f.severity] = (bySeverity[f.severity] || 0) + 1;
    byDetector[f.detector] = (byDetector[f.detector] || 0) + 1;
    byFile[f.file] = (byFile[f.file] || 0) + 1;
  }

  return {
    total: findings.length,
    bySeverity,
    byDetector,
    topFiles: Object.entries(byFile)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([file, count]) => ({ file, count })),
  };
}

module.exports = { deduplicate, summarize, fingerprint };
