'use strict';

const { customRegexScan } = require('./customRegexScanner');
const { keywordScan }     = require('./keywordScanner');
const { analyzeEntropy }  = require('./entropyAnalyzer');

const MAX_DEPTH = 1; // depth 1 is enough — avoids false positives from nested data

const BASE64_PATTERN     = /(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})/g;
const BASE64_URL_PATTERN = /(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2}==|[A-Za-z0-9_-]{3}=|[A-Za-z0-9_-]{4})/g;

function tryDecode(str) {
  try {
    const normalized = str.replace(/-/g, '+').replace(/_/g, '/');
    const decoded = Buffer.from(normalized, 'base64').toString('utf8');
    const printableRatio = (decoded.match(/[\x20-\x7E]/g) || []).length / decoded.length;
    if (printableRatio < 0.7) return null;
    if (decoded === str) return null;
    if (decoded.length < 6) return null;
    return decoded;
  } catch { return null; }
}

function extractBase64Candidates(content) {
  const candidates = [];
  const seen = new Set();
  for (const pattern of [BASE64_PATTERN, BASE64_URL_PATTERN]) {
    pattern.lastIndex = 0;
    let match;
    while ((match = pattern.exec(content)) !== null) {
      const encoded = match[0];
      if (encoded.length < 20 || seen.has(encoded)) continue;
      seen.add(encoded);
      candidates.push({ encoded, index: match.index });
    }
    pattern.lastIndex = 0;
  }
  return candidates;
}

function base64Scan(filename, content) {
  const findings = [];
  const lines = content.split('\n');
  const candidates = extractBase64Candidates(content);

  for (const { encoded, index } of candidates) {
    const lineNumber = content.substring(0, index).split('\n').length;
    const inComment  = (lines[lineNumber - 1] || '').trim().startsWith('//') ||
                       (lines[lineNumber - 1] || '').trim().startsWith('#');
    const decoded = tryDecode(encoded);
    if (!decoded) continue;

    const virtualFile = `${filename}[base64-decoded]`;
    const subFindings = [
      ...customRegexScan(virtualFile, decoded),
      ...keywordScan(virtualFile, decoded),
      ...analyzeEntropy(virtualFile, decoded),
    ];

    for (const sub of subFindings) {
      findings.push({
        ...sub,
        RuleID:      sub.RuleID,
        Description: `[Base64 encoded] ${sub.Description}`,
        File:        filename,
        StartLine:   lineNumber,
        EndLine:     lineNumber,
        Match:       encoded.substring(0, 20) + '...',
        Secret:      decoded.substring(0, 60),
        Fingerprint: `${filename}:base64:${sub.RuleID}:${lineNumber}`,
        Tags:        [...(sub.Tags || []), 'base64-encoded'],
        confidence:  Math.max((sub.confidence || 50) - 10, 20),
        detector:    'Base64Decoder',
        inComment,
        rawMatch:    decoded,
      });
    }
  }
  return findings;
}

module.exports = { base64Scan, tryDecode };
