/**
 * gitInfo.js
 * Reads git metadata for a file using "git log".
 * Used to populate Author, Email, Commit, Date, Message
 * when Gitleaks is not installed.
 *
 * Usage:
 *   const { getFileGitInfo, getRepoGitInfo } = require('./gitInfo');
 *   const info = getFileGitInfo(repoPath, 'config/default.json');
 *   // { author, email, commit, date, message, link }
 */

'use strict';

const { execSync } = require('child_process');
const path = require('path');

/**
 * Check if the path is inside a git repo
 */
function isGitRepo(repoPath) {
  try {
    execSync('git rev-parse --is-inside-work-tree', {
      cwd: repoPath, stdio: 'pipe'
    });
    return true;
  } catch { return false; }
}

/**
 * Get the remote GitHub/GitLab URL for building links
 */
function getRemoteUrl(repoPath) {
  try {
    const remote = execSync('git remote get-url origin', {
      cwd: repoPath, stdio: 'pipe', encoding: 'utf8'
    }).trim();
    // Convert SSH to HTTPS: git@github.com:user/repo.git -> https://github.com/user/repo
    return remote
      .replace(/^git@([^:]+):/, 'https://$1/')
      .replace(/\.git$/, '');
  } catch { return ''; }
}

/**
 * Get git log info for a specific file
 * Returns the MOST RECENT commit that touched this file
 */
function getFileGitInfo(repoPath, relativeFilePath) {
  if (!isGitRepo(repoPath)) return null;

  try {
    // Format: commit|author|email|date|subject
    const log = execSync(
      `git log -1 --format="%H|%an|%ae|%aI|%s" -- "${relativeFilePath}"`,
      { cwd: repoPath, stdio: 'pipe', encoding: 'utf8' }
    ).trim();

    if (!log) return null;

    const [commit, author, email, date, message] = log.split('|');
    const remoteUrl = getRemoteUrl(repoPath);

    return {
      commit:  commit  || '',
      author:  author  || '',
      email:   email   || '',
      date:    date    || '',
      message: message || '',
      link:    remoteUrl && commit
        ? `${remoteUrl}/blob/${commit}/${relativeFilePath}`
        : '',
    };
  } catch { return null; }
}

/**
 * Get git info for every file in a repo at once.
 * Returns a Map<relativeFilePath, gitInfo> for fast lookup.
 * Much faster than calling getFileGitInfo() per file.
 */
function getRepoGitInfo(repoPath) {
  const map = new Map();
  if (!isGitRepo(repoPath)) return map;

  try {
    // Get all files tracked by git with their last commit info
    const log = execSync(
      'git log --name-only --format="COMMIT|%H|%an|%ae|%aI|%s" --diff-filter=A',
      { cwd: repoPath, stdio: 'pipe', encoding: 'utf8' }
    );

    const remoteUrl = getRemoteUrl(repoPath);
    let currentMeta = null;

    for (const line of log.split('\n')) {
      if (line.startsWith('COMMIT|')) {
        const [, commit, author, email, date, message] = line.split('|');
        currentMeta = { commit, author, email, date, message, remoteUrl };
      } else if (line.trim() && currentMeta && !map.has(line.trim())) {
        const filePath = line.trim();
        map.set(filePath, {
          commit:  currentMeta.commit,
          author:  currentMeta.author,
          email:   currentMeta.email,
          date:    currentMeta.date,
          message: currentMeta.message,
          link:    currentMeta.remoteUrl && currentMeta.commit
            ? `${currentMeta.remoteUrl}/blob/${currentMeta.commit}/${filePath}`
            : '',
        });
      }
    }
  } catch {}

  return map;
}

module.exports = { getFileGitInfo, getRepoGitInfo, isGitRepo };
