'use strict';

/**
 * contextualConfidence.js
 * ========================
 * Context-Aware Secret Detection — assigns confidence_level and adjusts
 * numeric confidence for every finding BEFORE deduplication.
 *
 * THREE SIGNALS COMBINED:
 *
 *  1. KEYWORD SPECIFICITY
 *     How strongly does the keyword name alone signal a secret?
 *     password → MEDIUM  (common but not unambiguous)
 *     passwd   → MEDIUM  (shorter alias, still clear)
 *     pwd      → LOW     (too short, could be anything)
 *     secret   → HIGH    (unambiguous intent)
 *     jwt_secret → HIGH  (very specific service + type)
 *
 *  2. VALUE QUALITY
 *     Does the assigned value LOOK like a real secret?
 *     Checks: length, entropy, character variety, not a placeholder
 *
 *  3. SURROUNDING CONTEXT
 *     Where in the code does it appear?
 *     - In a comment      → confidence -15, never above MEDIUM
 *     - In a test file    → confidence -10, never above MEDIUM
 *     - In .env file      → confidence +5  (env files store real secrets)
 *     - Variable assigned → better than bare string
 *
 * OUTPUT  →  { confidence: number, confidence_level: 'HIGH'|'MEDIUM'|'LOW' }
 */

// ── Keyword specificity tiers ─────────────────────────────────────────────────
//
// HIGH (base 90)  — keyword name unambiguously means "this is a secret value"
//                   Only used to store credentials, not config or IDs.
//
// MEDIUM (base 75) — clearly credential-related but slightly ambiguous.
//                    'password' is correct but also used in UI labels, docs.
//
// LOW (base 55)   — generic / abbreviated / could mean many non-secret things.
//                   'pwd' could be "print working directory", db_port is not a secret.

const KEYWORD_TIERS = {

  // ── HIGH — unambiguous, only ever store a secret ──────────────────────────
  HIGH: new Set([
    // Generic secret markers
    'secret', 'secret_key', 'secretkey',
    // API keys
    'api_key', 'apikey', 'api_secret',
    // Auth tokens
    'auth_key', 'auth_token', 'authtoken',
    'access_token', 'accesstoken',
    'bearer_token', 'refresh_token', 'id_token',
    // Private key markers
    'private_key', 'privatekey',
    'client_secret',
    // AWS specific
    'aws_secret', 'aws_secret_access_key', 'aws_secret_key', 'aws_session_token',
    'awskey', 'awssecret', 'aws_key',
    // EC2 / infra
    'ec2_private_key',
    // Cloud providers
    'azure_client_secret', 'gcp_credentials',
    // Payment / services
    'stripe_secret', 'stripe_key', 'stripe_secret_key',
    'sendgrid_key', 'mailgun_key',
    'twilio_auth', 'slack_token',
    'github_token', 'gitlab_token',
    // Crypto / signing
    'encryption_key', 'signing_key', 'master_key',
    'ssh_key', 'rsa_key', 'pem_key',
    // JWT / webhook
    'webhook_secret', 'jwt_secret',
    // Vault
    'vault_token', 'vault_addr', 'vault_secret',
    // Ansible
    'ansible_ssh_private_key_file', 'ansible_become_pass',
    // HTTP headers that carry secrets
    'authorization', 'x-api-key', 'x-auth-token',
  ]),

  // ── MEDIUM — credential-related but slightly ambiguous ────────────────────
  MEDIUM: new Set([
    'password',        // common, but also used in documentation/UI copy
    'passwd',          // Unix alias — clear but shorter
    'passphrase',      // specific enough but sometimes used in non-secret contexts
    'access_key',      // could be AWS or generic; less specific than aws_access_key
    'ec2_key', 'ec2key',
    'db_password', 'database_password', 'db_pass',
    'connection_string',
    'adminpwd', 'adminpass', 'adminpassword',
  ]),

  // ── LOW — generic / abbreviated / definitely not always a secret ──────────
  LOW: new Set([
    'pwd',             // "print working directory" is more common in scripts
    'client_id',       // public identifier, not a secret
    'aws_access_key',  // key ID is semi-public (not the secret half)
    'db_user', 'db_username',   // usernames are not secrets
    'db_host', 'db_name', 'db_port', // pure config, not credentials
  ]),
};

// Base confidence score for each keyword tier
const KEYWORD_BASE = { HIGH: 90, MEDIUM: 75, LOW: 55 };

// ── Value quality assessment ──────────────────────────────────────────────────

/**
 * Score how much a value LOOKS like a real secret (0–15 bonus points).
 *
 * Strong value (all of: long, high entropy, not placeholder) → +15
 * Decent value (most signals) → +8
 * Weak value (short, low entropy, looks like placeholder)    → 0 or even -10
 */
function scoreValueQuality(value) {
  if (!value) return 0;

  let score = 0;

  // Length — real secrets are rarely < 8 chars
  if (value.length >= 32) score += 5;
  else if (value.length >= 16) score += 3;
  else if (value.length >= 8)  score += 1;
  else score -= 5;  // very short → suspicious

  // Character variety — real secrets mix char classes
  const hasUpper  = /[A-Z]/.test(value);
  const hasLower  = /[a-z]/.test(value);
  const hasDigit  = /[0-9]/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  const variety   = [hasUpper, hasLower, hasDigit, hasSymbol].filter(Boolean).length;
  if (variety >= 3) score += 5;
  else if (variety === 2) score += 2;

  // Shannon entropy — high entropy = looks random = likely a real secret
  const entropy = shannonEntropy(value);
  if (entropy >= 4.5) score += 5;
  else if (entropy >= 3.5) score += 2;
  else if (entropy < 2.5)  score -= 5;  // very low entropy = dictionary word

  // Placeholder penalty — obvious fake values
  const lv = value.toLowerCase();
  // Strong placeholders: definitely not a real secret → -20
  const strongPlaceholders = [
    'changeme', 'placeholder', 'your_', 'your-', 'xxxxx',
    'dummy', 'fake', 'insert_', 'replace_', 'fill_in',
  ];
  // Weak placeholders: common words also used in real secrets → -10
  const weakPlaceholders = [
    'password', 'secret', 'example', '12345', 'test',
    'todo', 'fixme', 'none', 'null', 'undefined', 'empty',
    'insert', 'replace', 'fill', 'here', 'value',
  ];
  if (strongPlaceholders.some(p => lv.includes(p))) score -= 20;
  else if (weakPlaceholders.some(p => lv.includes(p))) score -= 10;

  // All same character (aaaaa, 00000) → fake
  if (new Set(value).size <= 2) score -= 10;

  return score;
}

function shannonEntropy(str) {
  if (!str || str.length === 0) return 0;
  const freq = {};
  for (const ch of str) freq[ch] = (freq[ch] || 0) + 1;
  let e = 0;
  for (const c of Object.values(freq)) {
    const p = c / str.length;
    e -= p * Math.log2(p);
  }
  return e;
}

// ── File context bonuses / penalties ─────────────────────────────────────────

function scoreFileContext(filename) {
  const f = filename.toLowerCase();
  if (f.endsWith('.env') || f.includes('.env.'))  return +5;  // env files store real secrets
  if (f.includes('secret'))                        return +5;  // secrets.yml, secrets.json
  if (f.includes('credential'))                    return +5;
  if (f.endsWith('.example') || f.endsWith('.sample') ||
      f.endsWith('.template') || f.endsWith('.dist')) return -15; // template files — not real
  if (f.includes('test') || f.includes('spec') ||
      f.includes('mock') || f.includes('fixture'))  return -10; // test files
  if (f.endsWith('.md') || f.endsWith('.rst') ||
      f.endsWith('.txt'))                            return -10; // docs — probably example
  return 0;
}

// ── Main export ───────────────────────────────────────────────────────────────

/**
 * Compute context-aware confidence for a keyword finding.
 *
 * @param {string} keyword    — the matched keyword (e.g. "password", "pwd")
 * @param {string} value      — the assigned value (e.g. "MyP@ss123")
 * @param {string} filename   — file where the finding was found
 * @param {boolean} inComment — whether the line is a comment
 * @returns {{ confidence: number, confidence_level: string, context_signals: string[] }}
 */
function computeKeywordConfidence(keyword, value, filename, inComment) {
  const kw = keyword.toLowerCase();

  // Determine keyword tier
  let tier, base;
  if (KEYWORD_TIERS.HIGH.has(kw)) {
    tier = 'HIGH'; base = KEYWORD_BASE.HIGH;
  } else if (KEYWORD_TIERS.MEDIUM.has(kw)) {
    tier = 'MEDIUM'; base = KEYWORD_BASE.MEDIUM;
  } else {
    tier = 'LOW'; base = KEYWORD_BASE.LOW;
  }

  const signals = [`keyword_tier:${tier}`];
  let confidence = base;

  // Value quality adjustment
  const valueScore = scoreValueQuality(value);
  confidence += valueScore;
  if (valueScore >= 10)      signals.push('value:strong');
  else if (valueScore >= 3)  signals.push('value:decent');
  else if (valueScore < 0)   signals.push('value:weak');

  // File context
  const fileScore = scoreFileContext(filename);
  confidence += fileScore;
  if (fileScore > 0)  signals.push('file:secret_context');
  if (fileScore < 0)  signals.push('file:non_secret_context');

  // Comment penalty — secrets in comments are lower confidence
  if (inComment) {
    confidence -= 15;
    signals.push('in_comment');
  }

  // Clamp to 0–99
  confidence = Math.max(0, Math.min(99, confidence));

  // Derive confidence_level from final numeric confidence
  // (using same thresholds as customRegexScanner: ≥84 HIGH, ≥65 MEDIUM, else LOW)
  let confidence_level;
  if (confidence >= 84)      confidence_level = 'HIGH';
  else if (confidence >= 65) confidence_level = 'MEDIUM';
  else                       confidence_level = 'LOW';

  // Cap rules based on keyword tier:
  // MEDIUM tier (password, passwd, etc.) can never produce HIGH level —
  //   the keyword is too common/ambiguous to be certain it's a secret
  if (tier === 'MEDIUM' && confidence_level === 'HIGH') {
    confidence_level = 'MEDIUM';
    signals.push('capped:medium_keyword_tier');
  }
  // LOW tier (pwd, db_host, etc.) can never produce HIGH level.
  // But if found in a secret file (.env), floor to MEDIUM — still suspicious.
  if (tier === 'LOW') {
    if (confidence_level === 'HIGH') {
      confidence_level = 'MEDIUM';
      signals.push('capped:low_keyword_too_generic');
    }
    if (confidence_level === 'LOW' && fileScore > 0) {
      confidence_level = 'MEDIUM';
      signals.push('floored:secret_file_context');
    }
  }

  return { confidence, confidence_level, context_signals: signals };
}

/**
 * Compute confidence for a regex finding.
 * Regex findings use the rule's own confidence as the base,
 * but still get value-quality and file-context adjustments.
 *
 * @param {number}  ruleConfidence  — rule.confidence from patterns.js
 * @param {string}  value           — matched secret value
 * @param {string}  filename
 * @param {boolean} inComment
 * @returns {{ confidence: number, confidence_level: string, context_signals: string[] }}
 */
function computeRegexConfidence(ruleConfidence, value, filename, inComment) {
  const signals = [`rule_base:${ruleConfidence}`];
  let confidence = ruleConfidence;

  // Value quality — smaller effect for regex (the regex already validates format)
  const valueScore = Math.round(scoreValueQuality(value) * 0.5);
  confidence += valueScore;
  if (valueScore > 0)  signals.push('value:strong');
  if (valueScore < 0)  signals.push('value:weak_placeholder');

  // File context
  const fileScore = scoreFileContext(filename);
  confidence += fileScore;
  if (fileScore > 0)  signals.push('file:secret_context');
  if (fileScore < 0)  signals.push('file:non_secret_context');

  // Comment penalty
  if (inComment) {
    confidence -= 15;
    signals.push('in_comment');
  }

  confidence = Math.max(0, Math.min(99, confidence));

  let confidence_level;
  if (confidence >= 84)      confidence_level = 'HIGH';
  else if (confidence >= 65) confidence_level = 'MEDIUM';
  else                       confidence_level = 'LOW';

  return { confidence, confidence_level, context_signals: signals };
}

/**
 * Compute confidence for an entropy finding.
 * Entropy findings are always LOW — no keyword, no format, purely statistical.
 * But value quality and file context still shift the numeric score.
 *
 * @param {number}  entropy   — Shannon entropy of the candidate string
 * @param {string}  value
 * @param {string}  filename
 * @param {boolean} inComment
 * @returns {{ confidence: number, confidence_level: string, context_signals: string[] }}
 */
function computeEntropyConfidence(entropy, value, filename, inComment) {
  const signals = [`entropy:${entropy.toFixed(2)}`];

  // Base from entropy itself
  let confidence = Math.min(60, Math.round((entropy / 8) * 100));

  // File context (small effect)
  const fileScore = Math.round(scoreFileContext(filename) * 0.5);
  confidence += fileScore;
  if (fileScore > 0) signals.push('file:secret_context');

  if (inComment) {
    confidence -= 10;
    signals.push('in_comment');
  }

  confidence = Math.max(0, Math.min(60, confidence)); // hard cap at 60 for entropy-only

  // Entropy findings are always LOW — no pattern, no keyword, purely statistical
  return { confidence, confidence_level: 'LOW', context_signals: signals };
}

module.exports = {
  computeKeywordConfidence,
  computeRegexConfidence,
  computeEntropyConfidence,
  KEYWORD_TIERS,
  KEYWORD_BASE,
};
