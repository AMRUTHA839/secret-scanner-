'use strict';

const { CUSTOM_REGEX_RULES } = require('../config/patterns');
const {
  computeRegexConfidence,
} = require('./contextualConfidence'); // ADDED

function customRegexScan(filename, content) {
  const findings = [];
  const lines = content.split('\n');

  for (const rule of CUSTOM_REGEX_RULES) {
    rule.regex.lastIndex = 0;

    let match;
    while ((match = rule.regex.exec(content)) !== null) {
      const startLine = getLineNumber(content, match.index);
      const matchText = match[0];
      const secretValue = match[3] || match[2] || match[1] || matchText;
      const endLine = startLine + (matchText.split('\n').length - 1);
      const lineContent = lines[startLine - 1] || '';
      const inComment = isCommentLine(lineContent);

      if (isTestFile(filename) && rule.confidence < 90) continue;

      // CHANGED: context-aware confidence — rule base adjusted by value quality + file context
      const ctx = computeRegexConfidence(rule.confidence, secretValue, filename, inComment);

      findings.push({
        RuleID:           rule.id,
        Description:      rule.description,
        StartLine:        startLine,
        EndLine:          endLine,
        StartColumn:      getColumn(content, match.index),
        EndColumn:        getColumn(content, match.index + matchText.length - 1),
        Match:            matchText,
        Secret:           secretValue,
        File:             filename,
        SymlinkFile:      '',
        Commit:           '',
        Link:             '',
        Entropy:          calcEntropy(matchText),
        Author:           '',
        Email:            '',
        Date:             new Date().toISOString(),
        Message:          '',
        Tags:             rule.severity ? [rule.severity.toLowerCase()] : [],
        Fingerprint:      filename + ':' + rule.id + ':' + startLine,
        severity:         rule.severity,
        confidence:       ctx.confidence,        // CHANGED: context-aware
        confidence_level: ctx.confidence_level,  // CHANGED: HIGH/MEDIUM/LOW
        context_signals:  ctx.context_signals,   // ADDED: explains the score
        detector:         'CustomRegexScanner',
        inComment,
        rawMatch:         secretValue,
      });

      if (findings.length > 1000) break;
    }
    rule.regex.lastIndex = 0;
  }

  return findings;
}

function getLineNumber(content, index) {
  return content.substring(0, index).split('\n').length;
}

function getColumn(content, index) {
  const before = content.substring(0, index);
  const lastNewline = before.lastIndexOf('\n');
  return lastNewline === -1 ? index + 1 : index - lastNewline;
}

function calcEntropy(str) {
  if (!str) return 0;
  const freq = {};
  for (const ch of str) freq[ch] = (freq[ch] || 0) + 1;
  let e = 0;
  for (const c of Object.values(freq)) {
    const p = c / str.length;
    e -= p * Math.log2(p);
  }
  return parseFloat(e.toFixed(6));
}

function isCommentLine(line) {
  const t = line.trim();
  return t.startsWith('//') || t.startsWith('#') || t.startsWith('*') ||
         t.startsWith('/*') || t.startsWith('--');
}

function isTestFile(filename) {
  const l = filename.toLowerCase();
  return l.includes('.test.') || l.includes('.spec.') ||
         l.includes('__tests__') || l.includes('/test/') ||
         l.includes('/mock') || l.includes('/fixture');
}

module.exports = { customRegexScan };
