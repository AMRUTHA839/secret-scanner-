'use strict';

const { ENTROPY_CONFIG } = require('../config/patterns');
const {
  computeEntropyConfidence,
} = require('./contextualConfidence'); // ADDED

function shannonEntropy(str) {
  if (!str || str.length === 0) return 0;
  const freq = {};
  for (const ch of str) freq[ch] = (freq[ch] || 0) + 1;
  let e = 0;
  const len = str.length;
  for (const c of Object.values(freq)) { const p = c / len; e -= p * Math.log2(p); }
  return e;
}

function shouldSkipFile(filename) {
  const lower = filename.toLowerCase();
  return ENTROPY_CONFIG.skipExtensions.some(ext => lower.endsWith(ext));
}

function extractCandidates(line) {
  const candidates = [];
  const quotedPattern = /['"`]([^'"`\r\n]{8,})['"`]/g;
  let match;
  while ((match = quotedPattern.exec(line)) !== null) candidates.push(match[1]);
  const envPattern = /[A-Z_]{4,}\s*=\s*([A-Za-z0-9+/=_.-]{20,})/g;
  while ((match = envPattern.exec(line)) !== null) candidates.push(match[1]);
  return candidates;
}

function isLikelyFalsePositive(str) {
  if (/^[a-f0-9-]{36}$/.test(str)) return true;
  if (str.startsWith('http') || str.startsWith('//')) return true;
  if (str.startsWith('/') || str.startsWith('./') || str.startsWith('../')) return true;
  if (/^[a-z-]+$/.test(str) && str.includes('-')) return true;
  if (/^#?[0-9a-fA-F]{6,8}$/.test(str)) return true;
  if (new Set(str).size < 5) return true;
  if (str.split(' ').length > 4) return true;
  if (/^(mysql|pgsql|sqlite|sqlsrv):/.test(str) && !str.includes('@') && !str.includes('password')) return true;
  if (/^[w.-]+.(internal|local|com|net|org|io|dev)$/.test(str)) return true;
  if (/^d{1,3}.d{1,3}.d{1,3}.d{1,3}(:d+)?$/.test(str)) return true;
  if (/.(php|js|ts|py|rb|go|java|json|yaml|yml|toml|env|log|txt|xml)$/.test(str)) return true;
  if (/^[w]+:[w=.;]+$/.test(str) && !str.includes('@') && str.split('=').length > 2) return true;
  return false;
}

function getColumn(line, str) {
  const i = line.indexOf(str);
  return i === -1 ? 1 : i + 1;
}

function analyzeEntropy(filename, content) {
  if (shouldSkipFile(filename)) return [];

  const findings = [];
  const lines = content.split('\n');

  lines.forEach((line, idx) => {
    const inComment = line.trim().startsWith('//') || line.trim().startsWith('#') ||
                      line.trim().startsWith('*');

    const candidates = extractCandidates(line);
    for (const candidate of candidates) {
      if (candidate.length < ENTROPY_CONFIG.minLength ||
          candidate.length > ENTROPY_CONFIG.maxLength) continue;
      if (isLikelyFalsePositive(candidate)) continue;

      const entropy = shannonEntropy(candidate);
      if (entropy >= ENTROPY_CONFIG.threshold) {

        // CHANGED: context-aware confidence — always LOW level but numeric score
        // still reflects file context and entropy magnitude
        const ctx = computeEntropyConfidence(entropy, candidate, filename, inComment);

        findings.push({
          RuleID:           'high-entropy-string',
          Description:      'High entropy string detected (entropy: ' + entropy.toFixed(2) + ')',
          StartLine:        idx + 1,
          EndLine:          idx + 1,
          StartColumn:      getColumn(line, candidate),
          EndColumn:        getColumn(line, candidate) + candidate.length,
          Match:            candidate.length > 40
                              ? candidate.substring(0, 20) + '...' + candidate.substring(candidate.length - 10)
                              : candidate,
          Secret:           candidate,
          File:             filename,
          SymlinkFile:      '',
          Commit:           '',
          Link:             '',
          Entropy:          parseFloat(entropy.toFixed(6)),
          Author:           '',
          Email:            '',
          Date:             new Date().toISOString(),
          Message:          '',
          Tags:             [entropy >= 5.5 ? 'high' : 'medium'],
          Fingerprint:      filename + ':high-entropy:' + (idx + 1),
          severity:         entropy >= 5.5 ? 'HIGH' : 'MEDIUM',
          confidence:       ctx.confidence,        // CHANGED: context-aware numeric
          confidence_level: ctx.confidence_level,  // always 'LOW' — entropy only
          context_signals:  ctx.context_signals,   // ADDED: why this score
          detector:         'EntropyAnalyzer',
          inComment,
          rawMatch:         candidate,
        });
      }
    }
  });

  return findings;
}

module.exports = { analyzeEntropy, shannonEntropy };
