'use strict';

const { FUZZY_TARGETS } = require('../config/patterns');

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  if (a === b) return 0;
  let prev = Array.from({ length: n + 1 }, (_, i) => i);
  let curr = new Array(n + 1);
  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    for (let j = 1; j <= n; j++) {
      const cost = a[i-1] === b[j-1] ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j-1] + 1, prev[j-1] + cost);
    }
    [prev, curr] = [curr, prev];
  }
  return prev[n];
}

const LEET_MAP = { '@':'a','4':'a','3':'e','1':'i','!':'i','0':'o','5':'s','$':'s','7':'t','+':'t','8':'b','6':'g' };
function normalizeLeet(str) {
  return str.toLowerCase().split('').map(ch => LEET_MAP[ch] || ch).join('');
}

function extractTokens(line) {
  const tokens = [];
  const pattern = /[a-zA-Z0-9@$!_-]{4,20}/g;
  let m;
  while ((m = pattern.exec(line)) !== null) tokens.push({ token: m[0], index: m.index });
  return tokens;
}

function hasAssignmentContext(line, tokenIndex, tokenLength) {
  const start = Math.max(0, tokenIndex - 5);
  const end = Math.min(line.length, tokenIndex + tokenLength + 30);
  const context = line.substring(start, end);
  return /[:=]\s*['"`]?[^'"`\s]{4,}/.test(context);
}

function fuzzyScan(filename, content) {
  const findings = [];
  const lines = content.split('\n');

  lines.forEach((line, idx) => {
    // FIX 1: Comments are NOW scanned
    const inComment = line.trim().startsWith('//') || line.trim().startsWith('#') ||
                      line.trim().startsWith('*');

    const tokens = extractTokens(line);
    for (const { token, index } of tokens) {
      const normalized = normalizeLeet(token);
      for (const target of FUZZY_TARGETS) {
        if (Math.abs(normalized.length - target.length) > 3) continue;
        if (token.toLowerCase() === target) continue;
        const distance = levenshtein(normalized, target);
        const maxDistance = target.length <= 6 ? 1 : 2;
        if (distance > maxDistance) continue;
        if (!hasAssignmentContext(line, index, token.length)) continue;
        const before = line[index - 1];
        const after  = line[index + token.length];
        if (before && /[a-zA-Z]/.test(before)) continue;
        if (after  && /[a-zA-Z]/.test(after))  continue;

        const confidence = distance === 0 ? 60 : distance === 1 ? 50 : 40;
        findings.push({
          RuleID:       `fuzzy-${target}`,
          Description:  `Fuzzy match: "${token}" resembles "${target}" (edit distance: ${distance})`,
          StartLine:    idx + 1,
          EndLine:      idx + 1,
          StartColumn:  index + 1,
          EndColumn:    index + token.length + 1,
          Match:        token,
          Secret:       token,
          File:         filename,
          SymlinkFile:  '',
          Commit:       '',
          Link:         '',
          Entropy:      0,
          Author:       '',
          Email:        '',
          Date:         new Date().toISOString(),
          Message:      '',
          Tags:         ['medium'],
          Fingerprint:  `${filename}:fuzzy-${target}:${idx + 1}`,
          severity:     'MEDIUM',
          confidence:   inComment ? confidence - 10 : confidence,
          detector:     'FuzzyMatcher',
          inComment,
          rawMatch:     token,
          editDistance: distance,
          matchedTarget: target,
        });
        break;
      }
    }
  });
  return findings;
}

module.exports = { fuzzyScan, levenshtein, normalizeLeet };
