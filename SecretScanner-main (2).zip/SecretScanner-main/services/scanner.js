'use strict';

const fs   = require('fs');
const path = require('path');

const { runGitleaks }     = require('./gitleaksRunner');
const { customRegexScan } = require('./customRegexScanner');
const { analyzeEntropy }  = require('./entropyAnalyzer');
const { keywordScan }     = require('./keywordScanner');
const { base64Scan }      = require('./base64Decoder');
const { fuzzyScan }       = require('./fuzzyMatcher');
const { deduplicate, summarize } = require('./deduplicator');
const { getRepoGitInfo, isGitRepo } = require('./gitInfo');
const { enrichFindings }  = require('./secretEnricher');

// FIX 2: Only skip truly binary/media files — scan EVERYTHING else
// These are the only extensions that make no sense to scan as text
const BINARY_EXTENSIONS = new Set([
  '.png','.jpg','.jpeg','.gif','.svg','.ico','.webp',
  '.woff','.woff2','.ttf','.eot','.otf',
  '.mp4','.mp3','.wav','.avi','.mov',
  '.zip','.gz','.tar','.rar','.7z',
  '.exe','.bin','.dll','.so','.dylib','.class','.pyc',
  '.pdf','.doc','.xls','.ppt','.docx','.xlsx','.pptx',
  '.map',
]);

// Directories to never recurse into
const SKIP_DIRS = new Set([
  'node_modules','.git','dist','build','__pycache__',
  '.next','.nuxt','vendor','coverage','.cache',
]);

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

// ── scanContent ───────────────────────────────────────────────────────────────
async function scanContent(filename, content) {
  const start = Date.now();
  if (!content || typeof content !== 'string') {
    return { findings: [], summary: summarize([]), durationMs: 0 };
  }

  const [r, e, k, b, f] = await Promise.all([
    Promise.resolve(customRegexScan(filename, content)),
    Promise.resolve(analyzeEntropy(filename, content)),
    Promise.resolve(keywordScan(filename, content)),
    Promise.resolve(base64Scan(filename, content)),
    Promise.resolve(fuzzyScan(filename, content)),
  ]);

  const findings = deduplicate([...r, ...e, ...k, ...b, ...f]);
  return { findings, summary: summarize(findings), durationMs: Date.now() - start, scannedFiles: 1 };
}

// ── scanFile ──────────────────────────────────────────────────────────────────
async function scanFile(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (BINARY_EXTENSIONS.has(ext)) {
    return { findings: [], summary: summarize([]), skipped: true, reason: 'binary' };
  }
  let content;
  try {
    const stat = fs.statSync(filePath);
    if (stat.size > MAX_FILE_SIZE) {
      return { findings: [], summary: summarize([]), skipped: true, reason: 'too large' };
    }
    content = fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    return { findings: [], summary: summarize([]), skipped: true, reason: err.message };
  }
  return scanContent(filePath, content);
}

// ── walkDirectory ─────────────────────────────────────────────────────────────
// FIX 2: Walk ALL files — no whitelist, only skip binary extensions and skip dirs
function walkDirectory(dir, accumulated = []) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch { return accumulated; }

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      // Skip hidden dirs (.git) and known non-source dirs
      if (entry.name.startsWith('.')) continue;
      if (SKIP_DIRS.has(entry.name)) continue;
      walkDirectory(fullPath, accumulated);
      continue;
    }

    if (!entry.isFile()) continue;

    const ext = path.extname(entry.name).toLowerCase();

    // Skip binary extensions — scan EVERYTHING else
    if (BINARY_EXTENSIONS.has(ext)) continue;

    // Try to read as text — if it fails (binary content), skip silently
    accumulated.push(fullPath);
  }

  return accumulated;
}

// ── scanRepo ──────────────────────────────────────────────────────────────────
async function scanRepo(repoPath, options = {}) {
  const start = Date.now();
  if (!fs.existsSync(repoPath)) throw new Error(`Path does not exist: ${repoPath}`);

  console.log(`[Scanner] Starting scan of ${repoPath}`);

  // Layer 1: Gitleaks
  const gitleaksFindings = options.skipGitleaks
    ? [] : runGitleaks(repoPath, { scanHistory: options.scanHistory });
  console.log(`[Scanner] Gitleaks: ${gitleaksFindings.length} findings`);

  // Load git metadata once for the whole repo (Author, Email, Commit, Date)
  // getRepoGitInfo returns a Map<relFilePath, {author, email, commit, date, message, link}>
  const gitInfoMap = getRepoGitInfo(repoPath);
  if (gitInfoMap.size > 0) {
    console.log(`[Scanner] Git info loaded for ${gitInfoMap.size} files`);
  } else {
    console.log('[Scanner] No git history found — Author/Email will be empty');
  }

  // Walk ALL files in the path
  const files = walkDirectory(repoPath);
  console.log(`[Scanner] Scanning ${files.length} files with custom layers...`);

  const customFindings = [];
  let skipped = 0;

  for (const filePath of files) {
    let content;
    try {
      const stat = fs.statSync(filePath);
      if (stat.size > MAX_FILE_SIZE) { skipped++; continue; }
      content = fs.readFileSync(filePath, 'utf8');

      // Quick binary check — if >30% non-printable chars, skip
      const sample = content.substring(0, 512);
      const nonPrintable = (sample.match(/[\x00-\x08\x0E-\x1F\x7F-\x9F]/g) || []).length;
      if (nonPrintable / sample.length > 0.3) { skipped++; continue; }

    } catch { skipped++; continue; }

    const relPath = path.relative(repoPath, filePath);

    // Look up git info for this file — normalise path separators for Windows
    const gitKey = relPath.replace(/\\/g, '/');
    const git = gitInfoMap.get(gitKey) || gitInfoMap.get(relPath) || null;

    const layerFindings = [
      ...customRegexScan(relPath, content),
      ...analyzeEntropy(relPath, content),
      ...keywordScan(relPath, content),
      ...base64Scan(relPath, content),
      ...fuzzyScan(relPath, content),
    ];

    // Attach git metadata to every finding from this file
    for (const f of layerFindings) {
      if (git) {
        f.Author  = git.author;
        f.Email   = git.email;
        f.Commit  = git.commit;
        f.Date    = git.date;
        f.Message = git.message;
        f.Link    = git.link
          ? git.link.replace(relPath, `${relPath}#L${f.StartLine}`)
          : '';
      }
    }

    customFindings.push(...layerFindings);
  }

  console.log(`[Scanner] Custom layers: ${customFindings.length} raw findings (before dedup)`);
  if (skipped > 0) console.log(`[Scanner] Skipped ${skipped} binary/unreadable files`);

  const findings = deduplicate([...gitleaksFindings, ...customFindings]);
  console.log(`[Scanner] After dedup: ${findings.length} unique findings`);

  // Enrich findings with secret_type, repo_visibility, exposure_days, privilege, status
  const enriched = enrichFindings(findings, repoPath);

  return {
    findings: enriched,
    summary: summarize(enriched),
    durationMs: Date.now() - start,
    scannedFiles: files.length - skipped,
    skippedFiles: skipped,
    repoPath,
  };
}

module.exports = { scanRepo, scanContent, scanFile };
