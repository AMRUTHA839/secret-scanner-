/**
 * secretEnricher.js
 * Enriches each finding with:
 *   secret_type    — human-readable name for the secret category
 *   repo_visibility — Public / Private / Unknown (from git remote)
 *   exposure_days  — days since the file was first committed
 *   privilege      — Admin / High / Medium / Low (inferred from secret type)
 *   status         — Active (static — live API verification is out of scope)
 */

'use strict';

const { execSync } = require('child_process');

// ── Secret type map ───────────────────────────────────────────────────────────
// Maps RuleID patterns to human-readable secret type names
const SECRET_TYPE_MAP = [
  // AWS
  { match: /aws-access-key|aws_access_key/i,        type: 'AWS Access Key' },
  { match: /aws-secret-key|aws_secret/i,             type: 'AWS Secret Key' },
  { match: /aws-session-token/i,                     type: 'AWS Session Token' },

  // GitHub
  { match: /github-pat|github_token/i,               type: 'GitHub Personal Access Token' },
  { match: /github-oauth/i,                          type: 'GitHub OAuth Token' },
  { match: /github-app/i,                            type: 'GitHub App Token' },

  // Stripe
  { match: /stripe-secret/i,                         type: 'Stripe Secret Key' },
  { match: /stripe-publishable/i,                    type: 'Stripe Publishable Key' },

  // Google
  { match: /google-api-key/i,                        type: 'Google API Key' },
  { match: /gcp|google-cloud/i,                      type: 'GCP Credential' },

  // Database
  { match: /db-connection-string|database/i,         type: 'Database Connection String' },
  { match: /keyword-db.password|db_password/i,       type: 'Database Password' },

  // Tokens / JWT
  { match: /jwt/i,                                   type: 'JWT Secret' },
  { match: /keyword-jwt/i,                           type: 'JWT Secret' },

  // Private keys
  { match: /private-key|rsa|ssh|openssh|pem/i,       type: 'Private Key' },

  // Other services
  { match: /slack/i,                                 type: 'Slack Token' },
  { match: /sendgrid/i,                              type: 'SendGrid API Key' },
  { match: /twilio/i,                                type: 'Twilio Credential' },
  { match: /stripe/i,                                type: 'Stripe Key' },

  // Generic
  { match: /high-entropy/i,                          type: 'High Entropy Secret' },
  { match: /keyword-password|generic-secret/i,       type: 'Hardcoded Password' },
  { match: /keyword-api.key/i,                       type: 'API Key' },
  { match: /keyword-token/i,                         type: 'Access Token' },
  { match: /fuzzy/i,                                 type: 'Obfuscated Credential' },
  { match: /base64/i,                                type: 'Encoded Secret' },
];

// ── Privilege map ─────────────────────────────────────────────────────────────
// Maps secret type to privilege level
const PRIVILEGE_MAP = [
  { match: /AWS Access Key|AWS Secret Key|AWS Session Token/,    privilege: 'Admin' },
  { match: /GitHub Personal Access Token|GitHub OAuth/,          privilege: 'Admin' },
  { match: /Private Key|RSA|SSH/,                                privilege: 'Admin' },
  { match: /GCP Credential/,                                     privilege: 'Admin' },
  { match: /Database Connection String/,                         privilege: 'Admin' },
  { match: /Stripe Secret Key/,                                  privilege: 'High' },
  { match: /Stripe Publishable Key/,                             privilege: 'Low' },
  { match: /Google API Key/,                                     privilege: 'High' },
  { match: /JWT Secret/,                                         privilege: 'High' },
  { match: /Database Password/,                                  privilege: 'High' },
  { match: /Slack Token/,                                        privilege: 'High' },
  { match: /SendGrid|Twilio/,                                    privilege: 'Medium' },
  { match: /API Key|Access Token/,                               privilege: 'Medium' },
  { match: /Hardcoded Password/,                                 privilege: 'Medium' },
  { match: /High Entropy|Obfuscated|Encoded/,                    privilege: 'Low' },
];

// ── Repo visibility ───────────────────────────────────────────────────────────

/**
 * Determine repo visibility from git remote URL.
 * Heuristic: GitHub private repos are not publicly accessible.
 * We check if the remote URL is reachable without auth via curl/fetch.
 * Falls back to checking repo name patterns.
 *
 * Note: Without a GitHub API token, we can only make a best-effort guess.
 * If the remote URL contains "github.com", we mark it "Unknown (GitHub)" 
 * since we can't query visibility without an API call.
 */
function getRepoVisibility(repoPath) {
  try {
    const remote = execSync('git remote get-url origin', {
      cwd: repoPath, stdio: 'pipe', encoding: 'utf8'
    }).trim();

    // Local repo with no remote
    if (!remote) return 'Private';

    // GitHub/GitLab — can't determine without API call, flag as Unknown
    if (remote.includes('github.com')) return 'Unknown (GitHub — check manually)';
    if (remote.includes('gitlab.com')) return 'Unknown (GitLab — check manually)';
    if (remote.includes('bitbucket.org')) return 'Unknown (Bitbucket — check manually)';

    // Internal/self-hosted remotes are typically private
    if (remote.includes('.internal') || remote.includes('localhost') ||
        /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(remote)) return 'Private';

    return 'Unknown';
  } catch {
    return 'Local (no remote)';
  }
}

// ── Exposure days ─────────────────────────────────────────────────────────────

/**
 * Calculate how many days since the file was FIRST committed.
 * This is the exposure window — how long the secret has potentially been visible.
 * Uses the oldest commit for the file, not the most recent.
 */
function getExposureDays(repoPath, relativeFilePath) {
  try {
    // --follow tracks renames, --diff-filter=A finds when file was Added
    // Use --reverse to get the first (oldest) commit first
    const firstCommitDate = execSync(
      `git log --follow --diff-filter=A --reverse --format="%aI" -- "${relativeFilePath}"`,
      { cwd: repoPath, stdio: 'pipe', encoding: 'utf8' }
    ).trim().split('\n')[0]; // take the very first line (oldest commit)

    if (!firstCommitDate) return 0;

    const first = new Date(firstCommitDate);
    const now   = new Date();
    const diffMs = now - first;
    return Math.floor(diffMs / (1000 * 60 * 60 * 24));
  } catch {
    return 0;
  }
}

// ── Main enrichment ───────────────────────────────────────────────────────────

/**
 * Map a RuleID to a human-readable secret type
 */
function getSecretType(ruleId, description) {
  const text = `${ruleId} ${description}`;
  for (const { match, type } of SECRET_TYPE_MAP) {
    if (match.test(text)) return type;
  }
  return 'Unknown Secret';
}

/**
 * Map a secret type to a privilege level
 */
function getPrivilege(secretType) {
  for (const { match, privilege } of PRIVILEGE_MAP) {
    if (match.test(secretType)) return privilege;
  }
  return 'Low';
}

/**
 * Enrich all findings with secret_type, repo_visibility, exposure_days,
 * privilege, and status.
 *
 * Loads exposure data per-file (not per-finding) for performance.
 *
 * @param {Array}  findings  — deduplicated findings array
 * @param {string} repoPath  — local repo path
 * @returns {Array} enriched findings
 */
function enrichFindings(findings, repoPath) {
  const visibility     = getRepoVisibility(repoPath);
  const exposureCache  = new Map(); // file → exposure_days

  return findings.map(f => {
    const file       = f.File || f.file || '';
    const ruleId     = f.RuleID || f.ruleId || '';
    const desc       = f.Description || '';

    // Exposure days — cache per file to avoid calling git log per finding
    if (!exposureCache.has(file)) {
      exposureCache.set(file, getExposureDays(repoPath, file));
    }
    const exposureDays = exposureCache.get(file);

    const secretType = getSecretType(ruleId, desc);
    const privilege  = getPrivilege(secretType);

    return {
      ...f,
      secret_type:      secretType,
      repo_visibility:  visibility,
      exposure_days:    exposureDays,
      privilege:        privilege,
      status:           'Active',
    };
  });
}

module.exports = { enrichFindings, getSecretType, getPrivilege, getRepoVisibility, getExposureDays };
