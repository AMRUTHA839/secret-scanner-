'use strict';

const { SENSITIVE_KEYWORDS } = require('../config/patterns');
const {
  computeKeywordConfidence,
} = require('./contextualConfidence'); // ADDED

class AhoCorasick {
  constructor() {
    this.nodes = [{ children: new Map(), fail: 0, outputs: [] }];
  }
  addKeyword(keyword) {
    let cur = 0;
    for (const ch of keyword.toLowerCase()) {
      if (!this.nodes[cur].children.has(ch)) {
        this.nodes.push({ children: new Map(), fail: 0, outputs: [] });
        this.nodes[cur].children.set(ch, this.nodes.length - 1);
      }
      cur = this.nodes[cur].children.get(ch);
    }
    this.nodes[cur].outputs.push(keyword);
  }
  build() {
    const queue = [];
    for (const [, child] of this.nodes[0].children) {
      this.nodes[child].fail = 0;
      queue.push(child);
    }
    while (queue.length > 0) {
      const cur = queue.shift();
      for (const [ch, child] of this.nodes[cur].children) {
        let fail = this.nodes[cur].fail;
        while (fail !== 0 && !this.nodes[fail].children.has(ch)) fail = this.nodes[fail].fail;
        if (this.nodes[fail].children.has(ch)) {
          fail = this.nodes[fail].children.get(ch);
          if (fail === child) fail = 0;
        }
        this.nodes[child].fail = fail;
        this.nodes[child].outputs = [...this.nodes[child].outputs, ...this.nodes[fail].outputs];
        queue.push(child);
      }
    }
  }
  search(text) {
    const matches = [];
    let cur = 0;
    const lower = text.toLowerCase();
    for (let i = 0; i < lower.length; i++) {
      const ch = lower[i];
      while (cur !== 0 && !this.nodes[cur].children.has(ch)) cur = this.nodes[cur].fail;
      if (this.nodes[cur].children.has(ch)) cur = this.nodes[cur].children.get(ch);
      for (const kw of this.nodes[cur].outputs) {
        matches.push({ keyword: kw, index: i - kw.length + 1 });
      }
    }
    return matches;
  }
}

const ac = new AhoCorasick();
for (const kw of SENSITIVE_KEYWORDS) ac.addKeyword(kw);
ac.build();

function extractAssignedValue(line, keywordIndex, keyword) {
  const after = line.substring(keywordIndex + keyword.length);
  const matchWithQuotes = /^\s*(?:[:=]>?\s*)['"` + "`" + `]([^'"` + "`" + `\r\n]{6,})['"` + "`" + `]/;
  const matchNoQuotes   = /^\s*[:=]\s+([^\s'"` + "`" + `\r\n,;#]{6,})/;
  let value = null;
  const m1 = matchWithQuotes.exec(after);
  if (m1) value = m1[1];
  else {
    const m2 = matchNoQuotes.exec(after);
    if (m2) value = m2[1];
  }
  if (!value) return null;
  value = value.trim();
  const placeholders = ['your','xxx','placeholder','changeme','todo','example',
    'here','value','enter','fill','<','>','{','}','null','undefined','none','false','true'];
  const lower = value.toLowerCase();
  if (placeholders.some(p => lower.includes(p))) return null;
  if (value.length < 6) return null;
  if (/^[a-z]+$/.test(lower) && value.length < 10) return null;
  return value;
}

function getColumn(line, index) { return index + 1; }

function calcEntropy(str) {
  if (!str) return 0;
  const freq = {};
  for (const ch of str) freq[ch] = (freq[ch] || 0) + 1;
  let e = 0;
  for (const c of Object.values(freq)) { const p = c / str.length; e -= p * Math.log2(p); }
  return parseFloat(e.toFixed(6));
}

function keywordScan(filename, content) {
  const findings = [];
  const lines = content.split('\n');

  lines.forEach((line, idx) => {
    const lineNum = idx + 1;
    const trimmed = line.trim();
    const inComment = trimmed.startsWith('//') || trimmed.startsWith('#') ||
                      trimmed.startsWith('*')  || trimmed.startsWith('/*');

    const matches = ac.search(line);
    for (const { keyword, index } of matches) {
      const before = line[index - 1];
      if (before && /[a-zA-Z0-9_]/.test(before)) continue;

      const value = extractAssignedValue(line, index, keyword);
      if (!value) continue;

      // CHANGED: context-aware confidence per keyword instead of flat 65
      const ctx = computeKeywordConfidence(keyword, value, filename, inComment);

      const matchText = keyword + ' = "' + value + '"';
      findings.push({
        RuleID:           'keyword-' + keyword.replace(/[^a-z0-9]/g, '-'),
        Description:      'Sensitive keyword "' + keyword + '" with assigned value',
        StartLine:        lineNum,
        EndLine:          lineNum,
        StartColumn:      getColumn(line, index),
        EndColumn:        getColumn(line, index + keyword.length),
        Match:            matchText,
        Secret:           value,
        File:             filename,
        SymlinkFile:      '',
        Commit:           '',
        Link:             '',
        Entropy:          calcEntropy(value),
        Author:           '',
        Email:            '',
        Date:             new Date().toISOString(),
        Message:          '',
        Tags:             ['high'],
        Fingerprint:      filename + ':keyword-' + keyword + ':' + lineNum,
        severity:         'HIGH',
        confidence:       ctx.confidence,        // CHANGED: context-aware per keyword
        confidence_level: ctx.confidence_level,  // CHANGED: HIGH/MEDIUM/LOW per keyword
        context_signals:  ctx.context_signals,   // ADDED: why this score
        detector:         'AhoCorasickKeywordScanner',
        inComment,
        rawMatch:         value,
        keyword,
      });
    }
  });

  return findings;
}

module.exports = { keywordScan, AhoCorasick };
