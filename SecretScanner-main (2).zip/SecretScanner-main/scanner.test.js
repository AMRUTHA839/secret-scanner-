/**
 * scanner.test.js — SecretSentinel full test suite
 * Run: node scanner.test.js
 */
'use strict';

const { customRegexScan }          = require('./services/customRegexScanner');
const { analyzeEntropy, shannonEntropy } = require('./services/entropyAnalyzer');
const { keywordScan, AhoCorasick } = require('./services/keywordScanner');
const { base64Scan, tryDecode }    = require('./services/base64Decoder');
const { fuzzyScan, levenshtein, normalizeLeet } = require('./services/fuzzyMatcher');
const { deduplicate, fingerprint } = require('./services/deduplicator');
const { scanContent }              = require('./services/scanner');

let passed = 0, failed = 0;

function assert(label, condition, detail = '') {
  if (condition) { console.log(`  ✅ ${label}`); passed++; }
  else { console.error(`  ❌ ${label}${detail ? ' — ' + detail : ''}`); failed++; }
}
function section(name) {
  console.log(`\n${'─'.repeat(60)}\n  ${name}\n${'─'.repeat(60)}`);
}

// ── 1. Shannon Entropy ────────────────────────────────────────
section('Entropy Analyzer — shannonEntropy()');
assert('Empty string returns 0',         shannonEntropy('') === 0);
assert('Single char returns 0',          shannonEntropy('aaaaaaa') === 0);
assert('High entropy string > 4.2',      shannonEntropy('aB3$kL9mNpQrStUvWxYz2') > 4.2);
assert('Plain English word < 3.5',       shannonEntropy('password') < 3.5);

section('Entropy Analyzer — analyzeEntropy()');
const entropyFindings = analyzeEntropy('test.js',
  'const secretKey = "aB3kL9mNpQrStUvWxYzAB3kL9mN";\nconst name = "hello";');
assert('Detects high entropy string',    entropyFindings.length > 0);
assert('Has correct detector label',     entropyFindings[0]?.detector === 'EntropyAnalyzer');
assert('Skips .min.css files',           analyzeEntropy('styles.min.css', 'aB3kL9mNpQrStUvWxYzAB3kL9mN').length === 0);

// ── 2. Custom Regex Scanner ───────────────────────────────────
section('Custom Regex Scanner');
const regexFindings = customRegexScan('config.js', `
  const token = "ghp_AbCdEfGhIjKlMnOpQrStUvWxYz123456";
  const key   = "AIzaSyDXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
  const dbUrl = "mongodb://admin:supersecret@localhost:27017/prod";
`);
assert('Detects GitHub PAT',             regexFindings.some(f => f.RuleID === 'github-pat'));
assert('Detects Google API key',         regexFindings.some(f => f.RuleID === 'google-api-key'));
assert('Detects DB connection string',   regexFindings.some(f => f.RuleID === 'db-connection-string'));
assert('Comments scanned not skipped',   customRegexScan('config.js',
  '// const token = "ghp_AbCdEfGhIjKlMnOpQrStUvWxYz123456";').some(f => f.inComment === true));

section('New Rules — PDO, Vault, Bearer, JWT, Ansible');
assert('Detects PHP PDO password',
  customRegexScan('db.php', '$db = new PDO("mysql:host=db;dbname=crm","crm_admin","Summer2025!");')
    .some(f => f.RuleID === 'pdo-constructor'));
assert('Detects Vault token',
  customRegexScan('tf.vars', 'vault_token = "hvs.training-token-example-123456"')
    .some(f => f.RuleID === 'vault-token'));
assert('Detects Bearer token',
  customRegexScan('log', 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.training.payload')
    .some(f => f.RuleID === 'bearer-token'));
assert('Detects JWT standalone',
  customRegexScan('log', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.training.payload')
    .some(f => f.RuleID === 'jwt-token'));
assert('Detects Ansible SSH key',
  customRegexScan('inv', '10.0.1.24 ansible_ssh_private_key_file=~/.ssh/prod_rsa')
    .some(f => f.RuleID === 'ansible-ssh-key-file'));

// ── 3. Aho-Corasick ───────────────────────────────────────────
section('Aho-Corasick Multi-Pattern Search');
const ac = new AhoCorasick();
['password','secret','api_key'].forEach(k => ac.addKeyword(k));
ac.build();
const acMatches = ac.search('my_password and api_key are here');
assert('Finds "password"',               acMatches.some(m => m.keyword === 'password'));
assert('Finds "api_key"',                acMatches.some(m => m.keyword === 'api_key'));
assert('Does not find "token"',          !acMatches.some(m => m.keyword === 'token'));

section('Keyword Scanner — keywordScan()');
const kwFindings = keywordScan('app.js', `
  const password = "SuperSecret123!";
  const api_key  = "sk-live-abcdefghijklmnop";
`);
assert('Detects password assignment',    kwFindings.some(f => f.keyword === 'password'));
assert('Detects api_key assignment',     kwFindings.some(f => f.keyword === 'api_key'));
assert('Ignores placeholder values',     keywordScan('app.js','const password = "your-password-here";').length === 0);

// ── 4. Base64 Decoder ─────────────────────────────────────────
section('Base64 Decoder');
assert('Decodes valid Base64',           tryDecode('cGFzc3dvcmQ6c3VwZXJzZWNyZXQ=') === 'password:supersecret');
assert('Returns null for non-Base64',    tryDecode('hello world') === null);
const encoded = Buffer.from('const password = "SuperSecret123!"').toString('base64');
const b64Findings = base64Scan('config.js', `const cfg = "${encoded}";`);
assert('Finds secrets inside Base64',    b64Findings.length > 0);
assert('Reports original file path',     b64Findings.every(f => f.File === 'config.js'));
assert('Labels as Base64Decoder',        b64Findings.every(f => f.detector === 'Base64Decoder'));

// ── 5. Fuzzy Matcher ──────────────────────────────────────────
section('Fuzzy Matcher — levenshtein()');
assert('Same strings = 0',              levenshtein('password','password') === 0);
assert('One substitution = 1',          levenshtein('password','passward') === 1);
assert('One insertion = 1',             levenshtein('secret','secrets')    === 1);

section('Fuzzy Matcher — normalizeLeet()');
assert('Normalizes @ → a',             normalizeLeet('p@ssword') === 'password');
assert('Normalizes 0 → o',             normalizeLeet('passw0rd') === 'password');
assert('Normalizes 3 → e',             normalizeLeet('s3cret')   === 'secret');

section('Fuzzy Matcher — fuzzyScan()');
const fuzzyFindings = fuzzyScan('config.js',
  'const p4ssword = "SuperSecret123!";\nconst s3cr3t = "MySuperSecret";');
assert('Finds leet-speak password',     fuzzyFindings.some(f => f.matchedTarget === 'password'));

// ── 6. Deduplicator ───────────────────────────────────────────
section('Deduplicator — fingerprint()');
const f1 = { RuleID:'test', File:'app.js', StartLine:5, rawMatch:'abc123', Secret:'abc123' };
const f2 = { RuleID:'test', File:'app.js', StartLine:5, rawMatch:'abc123', Secret:'abc123' };
const f3 = { RuleID:'test', File:'app.js', StartLine:6, rawMatch:'abc123', Secret:'abc123' };
assert('Same finding = same fingerprint',      fingerprint(f1) === fingerprint(f2));
assert('Different line = different fingerprint', fingerprint(f1) !== fingerprint(f3));

section('Deduplicator — deduplicate()');
const dupInput = [
  { RuleID:'r1', File:'a.js', StartLine:1, rawMatch:'secret123', Secret:'secret123', severity:'HIGH',     confidence:80, detector:'Gitleaks',            Tags:['high'],     Entropy:4.5 },
  { RuleID:'r1', File:'a.js', StartLine:1, rawMatch:'secret123', Secret:'secret123', severity:'HIGH',     confidence:70, detector:'CustomRegexScanner',  Tags:['high'],     Entropy:4.5 },
  { RuleID:'r2', File:'b.js', StartLine:5, rawMatch:'token456',  Secret:'token456',  severity:'CRITICAL', confidence:90, detector:'Gitleaks',            Tags:['critical'], Entropy:5.0 },
];
const deduped = deduplicate(dupInput);
assert('Removes exact duplicates',             deduped.length === 2);
assert('Keeps higher confidence',              deduped.find(f => f.RuleID === 'r1')?.confidence === 80);
assert('Tracks both detectors in sources',     deduped.find(f => f.RuleID === 'r1')?.sources?.includes('CustomRegexScanner'));
assert('CRITICAL sorted before HIGH',          deduped[0].severity === 'CRITICAL');

section('Deduplication — same secret different detectors (findings 4+5 bug)');
const dupTokens = [
  { RuleID:'generic-secret-assignment', File:'old.tfvars', StartLine:1, Secret:'token = "hvs.training-token-123"',  rawMatch:'token = "hvs.training-token-123"',  severity:'HIGH',   confidence:80, detector:'CustomRegexScanner',  Tags:['high'],   Entropy:4.5 },
  { RuleID:'high-entropy-string',       File:'old.tfvars', StartLine:1, Secret:'hvs.training-token-123',            rawMatch:'hvs.training-token-123',            severity:'MEDIUM', confidence:65, detector:'EntropyAnalyzer',     Tags:['medium'], Entropy:4.4 },
];
const dedupedTokens = deduplicate(dupTokens);
assert('Same secret from 2 detectors → 1 finding', dedupedTokens.length === 1);
assert('Sources includes both detectors',           dedupedTokens[0]?.sources?.includes('EntropyAnalyzer'));

// ── 7. Full Pipeline ──────────────────────────────────────────
section('Full Pipeline — scanContent()');
(async () => {
  const result = await scanContent('secrets_test.js', `
    const githubToken = "ghp_AbCdEfGhIjKlMnOpQrStUvWxYz123456";
    const encoded     = "${Buffer.from('api_key = "sk-live-realkey12345678"').toString('base64')}";
    const dbUrl       = "mongodb://root:topsecret@db.example.com:27017/prod";
    const entropy     = "aB3kL9mNpQrStUvWxYzAB3kL9mNpQ";
    vault_token       = "hvs.training-token-example-123456";
  `);

  assert('Returns findings array',       Array.isArray(result.findings));
  assert('Returns summary object',       typeof result.summary === 'object');
  assert('Returns durationMs',           typeof result.durationMs === 'number');
  assert('Detects GitHub token',         result.findings.some(f => f.RuleID === 'github-pat'));
  assert('Detects DB connection string', result.findings.some(f => f.RuleID === 'db-connection-string'));
  assert('Detects Vault token',          result.findings.some(f => f.RuleID === 'vault-token'));
  assert('No duplicate findings',
    new Set(result.findings.map(f => f.Fingerprint)).size === result.findings.length);

  console.log(`\n${'═'.repeat(60)}`);
  console.log(`  RESULTS: ${passed} passed, ${failed} failed`);
  console.log('═'.repeat(60));
  if (failed > 0) process.exit(1);
})();
