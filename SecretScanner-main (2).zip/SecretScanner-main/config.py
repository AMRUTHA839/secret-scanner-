API_KEY = "demo-api-key"
PASSWORD = "secret123"
