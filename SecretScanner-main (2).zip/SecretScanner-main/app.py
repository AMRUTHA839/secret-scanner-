# import json
# from datetime import datetime
# from servicenow_incident import create_incident, update_incident

# # 🔥 Load config.json
# with open("config.json", "r") as f:
#     config = json.load(f)

# INSTANCE_URL = config["instanceUrl"]

# # 🔥 Load findings
# with open("scored-results.json", "r") as f:
#     data = json.load(f)

# findings = data.get("scored", [])

# incident_list = []
# incident_map = {}

# print("TYPE:", type(findings))
# print("COUNT:", len(findings))

# if findings:
#     print("FIRST FINDING:", findings[0])

# for idx, finding in enumerate(findings):

#     # 🔥 better unique key (prevents accidental merging)
#     key = (
#         finding.get("file"),
#         finding.get("secretType"),
#         idx
#     )

#     # 🔁 update existing incident
#     if key in incident_map:
#         sys_id = incident_map[key]["sys_id"]
#         update_incident(sys_id, finding)

#         finding["incidentNum"] = incident_map[key]["number"]
#         finding["snLink"] = (
#             f"{INSTANCE_URL}"
#             f"nav_to.do?uri=incident.do?sys_id={sys_id}"
#         )
#         continue

#     # 🆕 create new incident
#     result = create_incident(finding)

#     if result:
#         incident_list.append(result["number"])

#         incident_map[key] = {
#             "sys_id": result["sys_id"],
#             "number": result["number"]
#         }

#         # 🔥 attach incident info back to finding
#         finding["incidentNum"] = result["number"]
#         finding["snLink"] = (
            
#             #  f"{INSTANCE_URL}/nav_to.do?uri=incident.do?sys_id={result['sys_id']}"  # ← fixed /
#             f"{INSTANCE_URL}"
#             f"nav_to.do?uri=incident.do?sys_id={result['sys_id']}"
#         )

# # 📦 final output
# output = {
#     "createdAt": datetime.now(timezone.utc).isoformat(), 
#     "incidentNums": incident_list,
#     "total": len(incident_list),
#     "findings": findings
# }

# with open("servicenow_incidents.json", "w") as f:
#     json.dump(output, f, indent=2)

# print("servicenow_incidents.json updated")

import json
from datetime import datetime, timezone
from servicenow_incident import find_incident, create_incident, update_incident

# Load config.json
with open("config.json", "r") as f:
    config = json.load(f)

INSTANCE_URL = config["instanceUrl"].rstrip("/")  # ← strip trailing slash once

# Load findings
with open("scored-results.json", "r") as f:
    data = json.load(f)
if isinstance(data, list):
    findings = data
else:
    findings = data.get("scored", [])

incident_list = []
incident_map = {}

print("TYPE:", type(findings))
print("COUNT:", len(findings))

if findings:
    print("FIRST FINDING:", findings[0])

for finding in findings:
    # Dedup key: file + secretType + finding ID → each unique finding gets its own incident
    key = (
        finding.get("file"),
        finding.get("secretType"),
        finding.get("id")
    )

    # 1. Check in-memory cache first (from this run)
    if key in incident_map:
        sys_id = incident_map[key]["sys_id"]
        print(f"Updating existing incident (in-memory): {incident_map[key]['number']} for '{key}'")
        update_incident(sys_id, finding)
        finding["incidentNum"] = incident_map[key]["number"]
        finding["snLink"] = f"{INSTANCE_URL}/nav_to.do?uri=incident.do?sys_id={sys_id}"
        continue

    # 2. Check ServiceNow for existing incident (persistent dedup across runs)
    existing = find_incident(finding)
    if existing:
        print(f"Found existing incident in ServiceNow: {existing['number']} for '{key}'")
        incident_map[key] = {
            "sys_id": existing["sys_id"],
            "number": existing["number"]
        }
        update_incident(existing["sys_id"], finding)
        finding["incidentNum"] = existing["number"]
        finding["snLink"] = f"{INSTANCE_URL}/nav_to.do?uri=incident.do?sys_id={existing['sys_id']}"
        continue

    # 3. No duplicate found — create new incident
    print(f"Creating new incident for: {finding.get('file')} | {finding.get('secretType')}")
    
    result = create_incident(finding)
    
    print(f"Result: {result}")

    if result:
        incident_list.append(result["number"])
        incident_map[key] = {
            "sys_id": result["sys_id"],
            "number": result["number"]
        }
        finding["incidentNum"] = result["number"]
        finding["snLink"] = f"{INSTANCE_URL}/nav_to.do?uri=incident.do?sys_id={result['sys_id']}"
    else:
        print(f"FAILED to create incident for {finding.get('file')} | {finding.get('secretType')}")
# Final output
output = {
    "createdAt": datetime.now(timezone.utc).isoformat(),  # ← fixed deprecation warning
    "incidentNums": incident_list,
    "total": len(incident_list),
    "findings": findings
}

with open("servicenow_incidents.json", "w") as f:
    json.dump(output, f, indent=2)

print("servicenow_incidents.json updated")