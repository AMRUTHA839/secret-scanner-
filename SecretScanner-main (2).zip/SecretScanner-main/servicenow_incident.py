import requests
from requests.auth import HTTPBasicAuth
import json


# -----------------------------
# Load config dynamically
# -----------------------------
def load_config():
    with open("config.json", "r") as f:
        return json.load(f)


# -----------------------------
# AI Score -> Priority Mapping
# -----------------------------
def get_priority(ai_score):
    if ai_score is None:
        ai_score = 50 
    if ai_score >= 80:
        return 1   # P1
    elif ai_score >= 60:
        return 2   # P2
    elif ai_score >= 40:
        return 3   # P3
    else:
        return 4   # P4


# -----------------------------
# Find Incident by file + secretType
# -----------------------------
def find_incident(finding, config=None):
    """Query ServiceNow for an existing incident with the same file + secretType combination."""
    if config is None:
        config = load_config()

    INSTANCE_URL = config["instanceUrl"].rstrip("/")
    USERNAME = config["username"]
    PASSWORD = config["password"]

    # Build a search query: find incidents whose short_description matches (includes finding ID for uniqueness)
    file_path = finding.get("file", "Unknown File")
    secret_type = finding.get("secretType", "Secret")
    finding_id = finding.get("id", "unknown")
    short_description = f"[{finding_id}] {secret_type} detected in {file_path}"

    url = f"{INSTANCE_URL}/api/now/table/incident"
    params = {
        "sysparm_query": f"short_description={short_description}",
        "sysparm_limit": 1,
        "sysparm_fields": "sys_id,number,short_description"
    }

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    response = requests.get(
        url,
        auth=HTTPBasicAuth(USERNAME, PASSWORD),
        headers=headers,
        params=params,
        timeout=30
    )

    if response.status_code != 200:
        print(f"Failed to query ServiceNow: {response.status_code}")
        return None

    try:
        data = response.json()
        results = data.get("result", [])
        if results:
            incident = results[0]
            print(f"Found existing incident {incident['number']} for '{short_description}'")
            return {
                "number": incident["number"],
                "sys_id": incident["sys_id"]
            }
    except Exception as e:
        print("JSON Parse Error in find_incident:", e)
        print("Raw Response:", response.text)

    return None


# -----------------------------
# Create Incident
# -----------------------------
def create_incident(finding, config=None):

    if config is None:
        config = load_config()

    INSTANCE_URL = config["instanceUrl"].rstrip("/")  # ← add this
    
    USERNAME = config["username"]
    PASSWORD = config["password"]

    url = f"{INSTANCE_URL}/api/now/table/incident"

    ai_score = finding.get("ai_score", 0)
    priority = get_priority(ai_score)

    payload = {
        "short_description": f"[{finding.get('id', 'unknown')}] {finding.get('secretType', 'Secret')} detected in {finding.get('file', 'Unknown File')}",
        "description": finding.get("ai_justification", "No description available"),
        "urgency": 1 if priority == 1 else 2 if priority == 2 else 3,
        "impact": 1 if priority == 1 else 2 if priority == 2 else 3,
        "priority": priority
    }

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    # ← ADD THESE
    print(f"Calling ServiceNow URL: {url}")
    print(f"Payload: {payload}")
    print(f"Username: {USERNAME}")

    response = requests.post(
        url,
        auth=HTTPBasicAuth(USERNAME, PASSWORD),
        headers=headers,
        data=json.dumps(payload),
        timeout=30
    )

    # ← ADD THESE
    print(f"Status code: {response.status_code}")
    print(f"Response: {response.text[:500]}")  # first 500 chars

    if response.status_code in [200, 201]:
        # ... rest of your code

    

        print("Incident created successfully")

        if not response.text.strip():
            print("Empty response from ServiceNow")
            return None

        try:
            data = response.json()

            return {
                "number": data["result"]["number"],
                "sys_id": data["result"]["sys_id"]
            }

        except Exception as e:
            print("JSON Parse Error:", e)
            print("Raw Response:", response.text)
            return None

    print("Failed to create incident")
    print(response.status_code)
    print(response.text)

    return None

# -----------------------------
# Update Incident
# -----------------------------
def update_incident(sys_id, finding, config=None):

    if config is None:
        config = load_config()

    INSTANCE_URL = config["instanceUrl"].rstrip("/")
    USERNAME = config["username"]
    PASSWORD = config["password"]

    url = f"{INSTANCE_URL}/api/now/table/incident/{sys_id}"

    payload = {
        "comments": f"Updated finding [{finding.get('id', 'unknown')}] {finding.get('secretType')} in {finding.get('file')}"
    }

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    response = requests.patch(
        url,
        auth=HTTPBasicAuth(USERNAME, PASSWORD),
        headers=headers,
        data=json.dumps(payload),
        timeout=30
    )

    if response.status_code in [200, 201]:
        print("Incident updated successfully")
        return True

    print("Failed to update incident")
    print(response.status_code)
    print(response.text)

    return False